#include "testAddMessage.h"
#include  "AddOrderMessage.h"
#include <fstream>
#include <chrono>
#include <cmath>
uint64_t getTimeSteampinMS()
{
	return std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
}

void AddOrderMessageTest::SetUp()
{
	uint64_t timestamp = getTimeSteampinMS();
	
	messages::AddOrderMessage message;
	m_messageIn.setStockTicker("IBM");
	m_messageIn.setSide('A');
	m_messageIn.setSize(300);
	m_messageIn.setPriceI32(45);
	m_messageIn.setTimestamp(timestamp);
	m_messageIn.setOrderReferenceNumber(200);
}

TEST_F(AddOrderMessageTest, TestEndian) {
	uint16_t num16 = 16;
	auto result16BE = messages::swap_endian(num16);
	auto result16LE = messages::swap_endian(result16BE);
	EXPECT_EQ(num16, result16LE);

	uint32_t num32 = 32;
	auto result32BE = messages::swap_endian(num32);
	auto result32LE = messages::swap_endian(result32BE);
	EXPECT_EQ(num32, result32LE);

	uint64_t num64 = 64;
	auto result64BE = messages::swap_endian(num64);
	auto result64LE = messages::swap_endian(result64BE);
	EXPECT_EQ(num64, result64LE);
}

TEST_F(AddOrderMessageTest, WriteInandReadInStreamTest) {
	messages::WriteByteBuffer wbyteBuffer(m_buffer, sizeof(m_buffer));
	m_count = m_messageIn.WriteByteStreamIn(wbyteBuffer);
	EXPECT_EQ(m_count, messages::AddOrderMessageSizeIn);

	messages::AddOrderMessage messageResult;
	messages::ReadByteBuffer rbyteBuffer(m_buffer, m_count);
	auto byteReadCount = messageResult.ReadByteStreamIn(rbyteBuffer);
	
	EXPECT_EQ(m_count, byteReadCount);
	EXPECT_EQ(m_messageIn.getSide(), messageResult.getSide());
	EXPECT_EQ(m_messageIn.getSize(), messageResult.getSize());
	EXPECT_EQ(m_messageIn.getTimestamp(), messageResult.getTimestamp());
	EXPECT_EQ(m_messageIn.getOrderReferenceNumber(), messageResult.getOrderReferenceNumber());
	EXPECT_EQ(m_messageIn.getPriceI32(), messageResult.getPriceI32());
	EXPECT_STREQ(m_messageIn.getStockTicker(), messageResult.getStockTicker());
}

TEST_F(AddOrderMessageTest, WriteOutandReadOutStreamTest) {
	messages::WriteByteBuffer wbyteBuffer(m_buffer, sizeof(m_buffer));
	m_count = m_messageIn.WriteByteStreamOut(wbyteBuffer);
	EXPECT_EQ(m_count, messages::AddOrderMessageSizeOut);

	messages::AddOrderMessage messageResult;
	messages::ReadByteBuffer rbyteBuffer(m_buffer, m_count);
	auto byteReadCount = messageResult.ReadByteStreamOut(rbyteBuffer);

	EXPECT_EQ(m_count, byteReadCount);
	EXPECT_EQ(m_messageIn.getSide(), messageResult.getSide());
	EXPECT_EQ(m_messageIn.getSize(), messageResult.getSize());
	EXPECT_EQ(m_messageIn.getTimestamp(), messageResult.getTimestamp());
	EXPECT_EQ(m_messageIn.getOrderReferenceNumber(), messageResult.getOrderReferenceNumber());
	EXPECT_EQ(m_messageIn.getPriceI32(), messageResult.getPriceI32());
	EXPECT_STREQ(m_messageIn.getStockTicker(), messageResult.getStockTicker());
}

void AddOrderMessageTest::TearDown()
{

}