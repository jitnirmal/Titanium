#include "testPerformance.h"
#include  "Parser.h"
#include  "AddOrderMessage.h"
#include  "OrderReplacedMessage.h"
#include  "OrderCancelledMessage.h"
#include  "OrderExecutedMessage.h"
#include "MessageSequenceProcessor.h"
#include <random>
#include <functional>
#include <algorithm>
#include "ByteStream.h"
#include <fstream>
#include "Utils.h"

const std::string gtest_outfilePerf = "C:\\Users\\jitni\\Data\\gtest_binary_out_milion.bin";





void PerformanceTest::CreateAddMessage(uint32_t sequenceNo, const int qty, uint64_t orderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::AddOrderMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	wbyteBufferHeader.append(sequenceNo, true);
	messages::AddOrderMessage addOrderMessage;
	addOrderMessage.setOrderReferenceNumber(1);
	addOrderMessage.setTimestamp(core::getTimeStampI64());
	addOrderMessage.setSide('B');
	addOrderMessage.setSize(qty);
	addOrderMessage.setStockTicker("IBM");
	addOrderMessage.setPriceI32(300);
	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::AddOrderMessageSizeIn + 4);
	auto m_count = addOrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto addMessage = std::make_unique<messages::AddOrderMessage>(addOrderMessage);
	_msgVector.emplace_back(std::move(addMessage));

	auto addEvent = std::make_unique<core::MessageEvent >();
	addEvent->Init(m_buffer, messages::AddOrderMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(addEvent));

}

void PerformanceTest::CreateReplaceMessage(uint32_t sequenceNo, const int newQty, uint64_t orignicalOrderId, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderReplacedMessageSizeIn + 4;
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderReplacedMessage OrderMessage;
	OrderMessage.setOrderReferenceNumber(orignicalOrderId);
	OrderMessage.setNewOrderReferenceNumber(neworderId);
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setSize(newQty);
	OrderMessage.setPriceI32(300);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderReplacedMessageSizeIn);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto repMessage = std::make_unique<messages::OrderReplacedMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(repMessage));

	auto eventReplace = std::make_unique<core::MessageEvent >();
	eventReplace->Init(m_buffer, messages::OrderReplacedMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventReplace));

}

void PerformanceTest::CreateCancelMessage(uint32_t sequenceNo, const int cancelQty, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderCancelledMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	//wbyteBufferHeader.append(packetSize, true);
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderCancelledMessage OrderMessage;
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setOrderReferenceNumber(1);
	OrderMessage.setSize(cancelQty);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderCancelledMessageSizeIn + 4);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);
	
	auto execMessage = std::make_unique<messages::OrderCancelledMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(execMessage));


	auto eventCancel = std::make_unique<core::MessageEvent >();
	eventCancel->Init(m_buffer, messages::OrderCancelledMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventCancel));

}

void PerformanceTest::CreateExecutionMessage( uint32_t sequenceNo, const int fillQty, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderExecutedMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderExecutedMessage OrderMessage;
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setOrderReferenceNumber(1);
	OrderMessage.setSize(fillQty);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderCancelledMessageSizeIn + 4);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto cancelMessage = std::make_unique<messages::OrderExecutedMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(cancelMessage));

	auto eventExecute = std::make_unique<core::MessageEvent >();
	eventExecute->Init(m_buffer, messages::OrderExecutedMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventExecute));

}



void PerformanceTest::SetUp()
{
	_filePos = 0;

	long sequenceNo = 0;
	int refNo = 1;
	for (int i = 0; i < 250000; ++i)
	{
		++sequenceNo;
		CreateAddMessage(sequenceNo, 100, refNo);

		++sequenceNo;
		CreateReplaceMessage(sequenceNo, 50, refNo, refNo + 100);

		++sequenceNo;
		CreateCancelMessage(sequenceNo, 20, refNo);
		
		++sequenceNo;
		CreateExecutionMessage(sequenceNo, 10, refNo);

		++refNo;
	}

	
	

}

TEST_F(PerformanceTest, ProcessMillionOrdersSync) {
	Parser parser(20080812, gtest_outfilePerf);
	
	auto start = std::chrono::steady_clock::now();
	for (auto& it : _eventVector)
	{
		// this should generate 4 messages .. New -> Replace -> Cancel -> Execute
		parser.onUDPPacket((it->Data), it->Length);
	}
	auto end = std::chrono::steady_clock::now();
	std::cout << "====================================== SYNC MODE  =======================================\n";
	std::cout << "\t\t1 Million orders processing took " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() <<" milliseconds\n";
	std::cout << "=========================================================================================\n";
}

TEST_F(PerformanceTest, ProcessMillionOrdersASync) {
	Parser parser(20080812, gtest_outfilePerf,true);

	auto start = std::chrono::steady_clock::now();
	for (auto& it : _eventVector)
	{
		// this should generate 4 messages .. New -> Replace -> Cancel -> Execute
		parser.onUDPPacket((it->Data), it->Length);
	}
	auto end = std::chrono::steady_clock::now();
	std::cout << "====================================== ASYNC MODE  ======================================\n";
	std::cout << "\t\t1 Million orders processing took " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " milliseconds\n";
	std::cout << "=========================================================================================\n";
}




void PerformanceTest::TearDown()
{

}