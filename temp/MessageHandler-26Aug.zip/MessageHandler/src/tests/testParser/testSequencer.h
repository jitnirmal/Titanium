#include "gtest/gtest.h"
#include  "MessageSequenceProcessor.h"


class MessageSequenceProcessorTest : public ::testing::Test {
protected:
	virtual void SetUp();
	virtual void TearDown();

protected:
	std::vector<core::MessageEvent*> m_shuffledEvents;
	std::vector<core::MessageEvent*> m_duplicateEvents;
	std::vector<core::MessageEvent*> m_inSequenceEvents;
};
