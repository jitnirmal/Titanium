#include "testSequencer.h"
#include <random>
#include <algorithm>
#include <functional>
void MessageSequenceProcessorTest::SetUp()
{
	std::vector<int> sequenceIDs = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 , 12 };
	std::vector<int> duplicateIDs = { 1, 2, 3,3, 4, 5,6,6, 6, 7, 8, 9,9, 8, 10, 11 , 12 };

	std::vector<int> shuffeledIDs = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 , 12 };
	std::random_device rd;
	std::mt19937 g(rd());
	std::shuffle(shuffeledIDs.begin(), shuffeledIDs.end(), g);

	// prepare the vector of shuffled events (completely out of sequence)
	char buffer[100];

	m_inSequenceEvents.reserve(sequenceIDs.size());
	std::transform(std::begin(sequenceIDs), std::end(sequenceIDs), std::back_inserter(m_inSequenceEvents), [=](int n) {
		auto evt = new core::MessageEvent();
		evt->Init(buffer, sizeof(buffer), n++);
		return evt;
	});

	m_duplicateEvents.reserve(duplicateIDs.size());
	std::transform(std::begin(duplicateIDs), std::end(duplicateIDs), std::back_inserter(m_duplicateEvents), [=](int n) {
		auto evt = new core::MessageEvent();
		evt->Init(buffer, sizeof(buffer), n++);
		return evt;
	});

	m_shuffledEvents.reserve(shuffeledIDs.size());
	std::transform(std::begin(shuffeledIDs), std::end(shuffeledIDs), std::back_inserter(m_shuffledEvents), [=](int n) {
		auto evt = new core::MessageEvent();
		evt->Init(buffer, sizeof(buffer), n++);
		return evt;
	});
}

TEST_F(MessageSequenceProcessorTest, InSequenceMessages) {
	
	parser::MessageSequenceProcessor processor;
	std::vector<int> resultSequence; // we will capture the sequence ids only
	
	std::function<void(core::MessageEvent* event)> processEvents = [&](core::MessageEvent* event) {
		if (processor.IsMessageToBeProcessed(event) == true)
		{
			resultSequence.push_back(event->SequenceID);
			//	std::cout << "Processed Event1 " << event->SequenceID << std::endl;
			auto msg = processor.CheckIfPendingMessageCanBeProcessed();
			if (msg != nullptr)
			{
				processEvents(msg);
			}
		}
		else
		{
			//	std::cout << "Skipped Event " << event->SequenceID << std::endl;
		}
	};

	for (auto& event : m_inSequenceEvents)
	{
		processEvents(event);
	}

	std::vector<int> expectedSequence = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 , 12 };
	EXPECT_EQ(expectedSequence, resultSequence);
}


TEST_F(MessageSequenceProcessorTest, DuplicateMessages) {

	parser::MessageSequenceProcessor processor;
	std::vector<int> resultSequence; // we will capture the sequence ids only

	std::function<void(core::MessageEvent* event)> processEvents = [&](core::MessageEvent* event) {
		if (processor.IsMessageToBeProcessed(event) == true)
		{
			resultSequence.push_back(event->SequenceID);
			//	std::cout << "Processed Event1 " << event->SequenceID << std::endl;
			auto msg = processor.CheckIfPendingMessageCanBeProcessed();
			if (msg != nullptr)
			{
				processEvents(msg);
			}
		}
		else
		{
			//	std::cout << "Skipped Event " << event->SequenceID << std::endl;
		}
	};

	for (auto& event : m_duplicateEvents)
	{
		processEvents(event);
	}

	std::vector<int> expectedSequence = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 , 12 };
	EXPECT_EQ(expectedSequence, resultSequence);
}

TEST_F(MessageSequenceProcessorTest, ShuffledMessages) {

	parser::MessageSequenceProcessor processor;
	std::vector<int> resultSequence; // we will capture the sequence ids only

	std::function<void(core::MessageEvent* event)> processEvents = [&](core::MessageEvent* event) {
		if (processor.IsMessageToBeProcessed(event) == true)
		{
			resultSequence.push_back(event->SequenceID);
			//	std::cout << "Processed Event1 " << event->SequenceID << std::endl;
			auto msg = processor.CheckIfPendingMessageCanBeProcessed();
			if (msg != nullptr)
			{
				processEvents(msg);
			}
		}
		else
		{
			//	std::cout << "Skipped Event " << event->SequenceID << std::endl;
		}
	};

	for (auto& event : m_shuffledEvents)
	{
		processEvents(event);
	}

	std::vector<int> expectedSequence = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 , 12 };
	EXPECT_EQ(expectedSequence, resultSequence);
}

void MessageSequenceProcessorTest::TearDown()
{

}