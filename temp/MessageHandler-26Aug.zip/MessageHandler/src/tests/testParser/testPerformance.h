#include "gtest/gtest.h"
#include  "AddOrderMessage.h"
#include  "Service.h"


class PerformanceTest : public ::testing::Test {
protected:
	virtual void SetUp();
	virtual void TearDown();
private:
	void CreateAddMessage(uint32_t sequenceNo, const int qty, uint64_t orderId);
	void CreateReplaceMessage(uint32_t sequenceNo, const int newQty, uint64_t orignicalOrderId, uint64_t neworderId);
	void CreateCancelMessage(uint32_t sequenceNo, const int cancelQty, uint64_t neworderId);
	void CreateExecutionMessage(uint32_t sequenceNo, const int fillQty, uint64_t neworderId);

protected:
	std::vector<std::unique_ptr<core::MessageEvent>> _eventVector;
	std::vector<std::unique_ptr<messages::OrderMessage>> _msgVector;
	size_t _filePos;
};
