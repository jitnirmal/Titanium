#include "gtest/gtest.h"
#include  "AddOrderMessage.h"


class AddOrderMessageTest : public ::testing::Test {
protected:
	virtual void SetUp();
	virtual void TearDown();

protected:
	messages::AddOrderMessage m_messageIn;
	char m_buffer[500];
	uint16_t m_count{ 0 };
};
