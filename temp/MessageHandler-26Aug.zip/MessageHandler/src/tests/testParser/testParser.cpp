#include "testParser.h"
#include  "Parser.h"
#include  "AddOrderMessage.h"
#include  "OrderReplacedMessage.h"
#include  "OrderCancelledMessage.h"
#include  "OrderExecutedMessage.h"
#include "MessageSequenceProcessor.h"
#include <random>
#include <functional>
#include <algorithm>
#include "ByteStream.h"
#include <fstream>
#include "Utils.h"




std::string outfile = "F:\\2018\\Coding\\Challenge\\Hudson\\MesageParser\\data\\gtest_binary_out_test.bin";


void ParserTest::CreateAddMessage(uint32_t sequenceNo, const int qty, uint64_t orderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::AddOrderMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	wbyteBufferHeader.append(sequenceNo, true);
	messages::AddOrderMessage addOrderMessage;
	addOrderMessage.setOrderReferenceNumber(1);
	addOrderMessage.setTimestamp(core::getTimeStampI64());
	addOrderMessage.setSide('B');
	addOrderMessage.setSize(qty);
	addOrderMessage.setStockTicker("IBM");
	addOrderMessage.setPriceI32(300);
	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::AddOrderMessageSizeIn + 4);
	auto m_count = addOrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto addMessage = std::make_unique<messages::AddOrderMessage>(addOrderMessage);
	_msgVector.emplace_back(std::move(addMessage));

	auto addEvent = std::make_unique<core::MessageEvent >();
	addEvent->Init(m_buffer, messages::AddOrderMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(addEvent));

}

void ParserTest::CreateReplaceMessage(uint32_t sequenceNo, const int newQty, uint64_t orignicalOrderId, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderReplacedMessageSizeIn + 4;
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderReplacedMessage OrderMessage;
	OrderMessage.setOrderReferenceNumber(orignicalOrderId);
	OrderMessage.setNewOrderReferenceNumber(neworderId);
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setSize(newQty);
	OrderMessage.setPriceI32(300);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderReplacedMessageSizeIn);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto repMessage = std::make_unique<messages::OrderReplacedMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(repMessage));

	auto eventReplace = std::make_unique<core::MessageEvent >();
	eventReplace->Init(m_buffer, messages::OrderReplacedMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventReplace));

}

void ParserTest::CreateCancelMessage(uint32_t sequenceNo, const int cancelQty, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderCancelledMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	//wbyteBufferHeader.append(packetSize, true);
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderCancelledMessage OrderMessage;
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setOrderReferenceNumber(1);
	OrderMessage.setSize(cancelQty);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderCancelledMessageSizeIn + 4);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);
	
	auto execMessage = std::make_unique<messages::OrderCancelledMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(execMessage));


	auto eventCancel = std::make_unique<core::MessageEvent >();
	eventCancel->Init(m_buffer, messages::OrderCancelledMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventCancel));

}

void ParserTest::CreateExecutionMessage( uint32_t sequenceNo, const int fillQty, uint64_t neworderId)
{
	char m_buffer[100];
	messages::WriteByteBuffer wbyteBufferHeader(m_buffer, sizeof(m_buffer));

	uint16_t packetSize = messages::OrderExecutedMessageSizeIn + sizeof(uint16_t) + sizeof(uint32_t);
	wbyteBufferHeader.append(sequenceNo, true);

	messages::OrderExecutedMessage OrderMessage;
	OrderMessage.setTimestamp(core::getTimeStampI64());
	OrderMessage.setOrderReferenceNumber(1);
	OrderMessage.setSize(fillQty);

	messages::WriteByteBuffer wbyteBufferMessage(m_buffer + 4, messages::OrderCancelledMessageSizeIn + 4);
	auto m_count = OrderMessage.WriteByteStreamIn(wbyteBufferMessage);

	auto cancelMessage = std::make_unique<messages::OrderExecutedMessage>(OrderMessage);
	_msgVector.emplace_back(std::move(cancelMessage));

	auto eventExecute = std::make_unique<core::MessageEvent >();
	eventExecute->Init(m_buffer, messages::OrderExecutedMessageSizeIn + 4);
	_eventVector.emplace_back(std::move(eventExecute));

}



void ParserTest::SetUp()
{
	_filePos = 0;

	long sequenceNo = 0;

	int refNo = 1;

	++sequenceNo;
	CreateAddMessage(sequenceNo, 100, refNo);
	
	++sequenceNo;
	CreateReplaceMessage( sequenceNo, 50, refNo, refNo+100);

	++sequenceNo;
	CreateCancelMessage(sequenceNo, 20, refNo);
	
	++sequenceNo;
	CreateExecutionMessage( sequenceNo, 10, refNo);
	
	Parser parser(20080812, outfile);
	for (auto& it : _eventVector)
	{
		// this should generate 4 messages .. New -> Replace -> Cancel -> Execute
		parser.onUDPPacket((it->Data), it->Length);
	}

	

}


TEST_F(ParserTest, AddOrderMessage) {
	
	std::ifstream infile;
	infile.open(outfile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char MessageBuffer[500];
		infile.read(MessageBuffer, messages::AddOrderMessageSizeOut);
		messages::AddOrderMessage resultAddMessage;
		messages::ReadByteBuffer rbyteBufferAddMessageOut(MessageBuffer, messages::AddOrderMessageSizeOut);
		auto countAdd = resultAddMessage.ReadByteStreamOut(rbyteBufferAddMessageOut);
		
		const auto& expectedAddmessage = _msgVector[0];

		EXPECT_STREQ(expectedAddmessage->getStockTicker(), resultAddMessage.getStockTicker());
		EXPECT_EQ(expectedAddmessage->getTimestamp(), resultAddMessage.getTimestamp());
		EXPECT_EQ(expectedAddmessage->getOrderReferenceNumber(), resultAddMessage.getOrderReferenceNumber());
		EXPECT_EQ(expectedAddmessage->getSide(), resultAddMessage.getSide());
		EXPECT_EQ(expectedAddmessage->getSize(), resultAddMessage.getSize());
	//	EXPECT_EQ(expectedAddmessage->getPriceI64(), resultAddMessage.getPriceI64());
	}
	infile.close();
}

TEST_F(ParserTest, OrderReplaceMessage) {
	
	std::ifstream infile;
	infile.open(outfile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char MessageBuffer[500];
		infile.read(MessageBuffer, messages::OrderReplacedMessageSizeOut);

		messages::OrderReplacedMessage resultMessage;
		messages::ReadByteBuffer rbyteBufferReplaceMessageOut(MessageBuffer, messages::OrderReplacedMessageSizeOut);
		auto countReplace = resultMessage.ReadByteStreamOut(rbyteBufferReplaceMessageOut);

		auto& expectedmessage = _msgVector[1];

		// we never set the stock ticker.. so Order store should get this filled from parser
		EXPECT_STREQ("IBM", resultMessage.getStockTicker());
		EXPECT_EQ(expectedmessage->getTimestamp(), resultMessage.getTimestamp());
		EXPECT_EQ(expectedmessage->getOrderReferenceNumber(), resultMessage.getOrderReferenceNumber());
		//EXPECT_EQ(expectedmessage->getSize(), resultMessage.getSize());
		//EXPECT_EQ(expectedmessage->getPriceI32(), resultMessage.getPriceI32());
	}
	infile.close();

}

TEST_F(ParserTest, OrderExecuteMessage) {
	
	std::ifstream infile;
	infile.open(outfile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char MessageBuffer[500];
		infile.read(MessageBuffer, messages::OrderExecutedMessageOut);
		messages::OrderExecutedMessage resultMessage;
		messages::ReadByteBuffer rbyteBufferExecMessageOut(MessageBuffer, messages::OrderExecutedMessageOut);
		auto countExec = resultMessage.ReadByteStreamOut(rbyteBufferExecMessageOut);

		auto& expectedmessage = _msgVector[2];

		EXPECT_STREQ("IBM", resultMessage.getStockTicker());
		EXPECT_EQ(expectedmessage->getTimestamp(), resultMessage.getTimestamp());
		EXPECT_EQ(expectedmessage->getOrderReferenceNumber(), resultMessage.getOrderReferenceNumber());
		//EXPECT_EQ(expectedmessage->getSize(), resultMessage.getSize());
	}
	infile.close();

}

TEST_F(ParserTest, OrderCancelMessage) {
	
	std::ifstream infile;
	infile.open(outfile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char MessageBuffer[500];
		
		infile.read(MessageBuffer, messages::OrderCancelledMessageOut);
		messages::OrderCancelledMessage resultMessage;
		messages::ReadByteBuffer rbyteBufferCancelMessageOut(MessageBuffer, messages::OrderCancelledMessageOut);
		auto countCancel = resultMessage.ReadByteStreamOut(rbyteBufferCancelMessageOut);

		auto& expectedmessage = _msgVector[3];

		EXPECT_STREQ("IBM", resultMessage.getStockTicker());
		EXPECT_EQ(expectedmessage->getTimestamp(), resultMessage.getTimestamp());
		EXPECT_EQ(expectedmessage->getOrderReferenceNumber(), resultMessage.getOrderReferenceNumber());
		//EXPECT_EQ(expectedmessage->getSize(), resultMessage.getSize());
	}
	infile.close();
}




void ParserTest::TearDown()
{

}