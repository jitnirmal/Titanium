#include "OrderStore.h"
namespace parser {
	OrderStore::OrderStore()
	{
		
	}

	void OrderStore::process(MessagePtr& messagePtr)
	{
		if (messagePtr->getMsgType() == 'A')
		{
			// store the new order
			auto order = std::make_unique<messages::Order>(messagePtr->getOrder());
			_orderStore.insert(std::make_pair(messagePtr->getOrderReferenceNumber(), std::move(order)));
		}
		else 
		{
			const auto& iter = _orderStore.find(messagePtr->getOrderReferenceNumber());
			if (iter != _orderStore.end())
			{
				auto& order = iter->second;
				if (messagePtr->getMsgType() == 'R' || messagePtr->getMsgType() == 'X' || messagePtr->getMsgType() == 'C')
				{
					messagePtr->setStockTicker(order->StockTicker);
				}
			}
		}
		
	}

}

