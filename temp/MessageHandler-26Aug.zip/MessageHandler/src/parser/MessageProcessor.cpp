#include "MessageProcessor.h"

namespace parser {
	MessageProcessor::MessageProcessor(const std::string& file)
		: Service("MessageProcessor")
	{
		_outFileStream.open(file, std::ios::binary | std::ios::out);
		if (!_outFileStream.is_open())
		{
			// throw exception
		}
	}
	MessageProcessor::~MessageProcessor()
	{
		_outFileStream.flush();
		_outFileStream.close();
	}
	void MessageProcessor::onMessageUpdate(core::MessageEvent* event)
	{
		updateSequeneID(event);
		if (_sequenceProcessor.IsMessageToBeProcessed(event) == true)
		{
			_translator.Translate(event);
			WriteEventToFile(event);
			auto msg = _sequenceProcessor.CheckIfPendingMessageCanBeProcessed();
			if (msg != nullptr)
			{
				onMessageUpdate(msg);
			}
		}
	}
	void MessageProcessor::updateSequeneID(core::MessageEvent* event)
	{
		messages::ReadByteBuffer rbyteBufferMessage(event->Data, sizeof(uint32_t));
		event->SequenceID = rbyteBufferMessage.read<uint32_t>(true);

		//messages::ReadByteBuffer rbyteBufferHeader(messageEventPtr->Data, messageEventPtr->Length);
		//auto packetSizeOut = rbyteBufferHeader.read<uint16_t>(true);
		//auto sequenceNoOut = rbyteBufferHeader.read<uint32_t>(true);
	}

	void MessageProcessor::WriteEventToFile(core::MessageEvent* event)
	{
		static int records{0};
		_outFileStream.write(event->Data, event->Length);
		if (++records % 10000 == 0)
		{
			_outFileStream.flush();
		}
	}
	
}
