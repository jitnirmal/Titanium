#include "MessageProcessor.h"
#include <fstream>
namespace parser {
	MessageProcessor::MessageProcessor(const std::string& file, bool async) noexcept
		: Service("MessageProcessor", async),
		_recordsProcessed(0)
	{
		_outFileStream.open(file, std::ios::binary | std::ios::out);
		if (!_outFileStream.is_open())
		{
			// throw exception
		}
	}
	MessageProcessor::~MessageProcessor() noexcept
	{
		_outFileStream.flush();
		_outFileStream.close();
	}

	/*
	*   Receive the message event and find out if there any duplicacy or out of sequence
	*   For out of sequence messages, it parks it for later processing with _sequenceProcessor
	*   with every successful message processing it will revaluate that whether _sequenceProcessor 
	*   have any more immediate sequnce message that can be processed now
	*/

	void MessageProcessor::OnMessageUpdate(core::MessageEvent* event)
	{
		updateSequeneID(event);
		if (_sequenceProcessor.IsMessageToBeProcessed(event) == true)
		{
			_translator.Translate(event);
			WriteEventToFile(event);
			auto msg = _sequenceProcessor.CheckIfPendingMessageCanBeProcessed();
			if (msg != nullptr)
			{
				OnMessageUpdate(msg);
			}
		}
	}
	void MessageProcessor::updateSequeneID(core::MessageEvent* event)
	{
		messages::ReadByteBuffer rbyteBufferMessage(event->Data, sizeof(uint32_t));
		event->SequenceID = rbyteBufferMessage.read<uint32_t>(true);

		//messages::ReadByteBuffer rbyteBufferHeader(messageEventPtr->Data, messageEventPtr->Length);
		//auto packetSizeOut = rbyteBufferHeader.read<uint16_t>(true);
		//auto sequenceNoOut = rbyteBufferHeader.read<uint32_t>(true);
	}

	void MessageProcessor::WriteEventToFile(core::MessageEvent* event)
	{
		_outFileStream.write(event->Data, event->Length);
		if (++_recordsProcessed % 10000 == 0)
		{
			// flush after 10K records
			_outFileStream.flush();
		}
	}
	
}
