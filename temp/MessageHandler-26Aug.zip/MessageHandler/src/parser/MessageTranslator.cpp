#include "MessageTranslator.h"
#include  "ByteStream.h"
#include  "AddOrderMessage.h"
#include  "OrderCancelledMessage.h"
#include  "OrderExecutedMessage.h"
#include  "OrderReplacedMessage.h"

namespace parser {
	MessageTranslator::MessageTranslator()
	{
		_messageSerializers['A'] = std::make_unique<messages::AddOrderMessage>();
		_messageSerializers['C'] = std::make_unique<messages::OrderCancelledMessage>();
		_messageSerializers['X'] = std::make_unique<messages::OrderExecutedMessage>();
		_messageSerializers['R'] = std::make_unique<messages::OrderReplacedMessage>();
	}

	void MessageTranslator::Translate(core::MessageEvent* event)
	{
		uint16_t size = messages::HeaderMessageSizeIn;
		messages::ReadByteBuffer rbyteBufferMsgType(event->Data + size, size);
		auto msgType = rbyteBufferMsgType.read<char>();
		

		auto serializerIter = _messageSerializers.find(msgType);
		if (serializerIter != _messageSerializers.end())
		{
		
			//rbyteBufferMessage.Reset(event->Data + count, sizeof(event->Length));
			auto& messageResult = serializerIter->second;
			
			messages::ReadByteBuffer rbyteBufferMessage(event->Data + size , event->Length - size);
			auto byteReadCount = messageResult->ReadByteStreamIn(rbyteBufferMessage);

			_orderStore.process(messageResult);

			messages::WriteByteBuffer wbyteBuffer(event->Data, core::MAX_MESSAGE_SIZE);
			event->Length = messageResult->WriteByteStreamOut(wbyteBuffer);

		}
	}

}

