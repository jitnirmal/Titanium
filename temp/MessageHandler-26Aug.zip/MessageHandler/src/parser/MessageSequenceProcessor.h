#pragma once

#include "Service.h"
#include <map>
#include  "OrderMessage.h"
#include <memory>
#include <list>

namespace parser {
	/* MessageSequenceProcessor
	*
	* Handle the sequencing of the messages
	* It handles
	*  - out of sequence message
	*  - duplicate messages
	*/
	class MessageSequenceProcessor {
	public:
		MessageSequenceProcessor()noexcept;
		bool IsMessageToBeProcessed(core::MessageEvent* event) noexcept;
		core::MessageEvent* CheckIfPendingMessageCanBeProcessed() noexcept;
	private:
		std::map<int, core::MessageEvent*> _sequenceTable;
		long _currentSequenceId;
	};
}
