#pragma once

#include "Service.h"
#include <map>
#include  "OrderMessage.h"
#include <memory>
#include <list>
//using MessagePtr = std::unique_ptr<messages::Order>;

namespace parser {
	class MessageSequenceProcessor {
	public:
		MessageSequenceProcessor();
		bool IsMessageToBeProcessed(core::MessageEvent* event);
		core::MessageEvent* CheckIfPendingMessageCanBeProcessed();
	private:
		std::map<int, core::MessageEvent*> _sequenceTable;
		long _currentSequenceId;
	};
}
