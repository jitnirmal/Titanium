#pragma once

#include "Service.h"
#include <list>
#include "MessageTranslator.h"
#include "MessageSequenceProcessor.h"
#include <fstream>

namespace parser {
	
	/* MessageProcessor
	*
	*  Handles incoming message events,translate them and invoke file writing.
	*
	*/

	class MessageProcessor : public core::Service {
	public:
		MessageProcessor(const std::string& file, bool async = false) noexcept;
		~MessageProcessor() noexcept ;

		/* MessageProcessor
		* Translate the events from in -> out format
		*  write to file 
		*/
		virtual void OnMessageUpdate(core::MessageEvent* event) override;

	private:
		void WriteEventToFile(core::MessageEvent* event);
		void updateSequeneID(core::MessageEvent* event);
	private:
		MessageTranslator _translator;
		std::ofstream _outFileStream;
		long _recordsProcessed;
		MessageSequenceProcessor _sequenceProcessor;
	};
}
