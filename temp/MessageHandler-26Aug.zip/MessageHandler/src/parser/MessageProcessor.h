#pragma once

#include "Service.h"
#include <list>
#include "MessageTranslator.h"
#include "MessageSequenceProcessor.h"
#include <fstream>

namespace parser {
	class MessageProcessor : public core::Service {
	public:
		MessageProcessor(const std::string& file);
		~MessageProcessor();
		virtual void onMessageUpdate(core::MessageEvent* event) override;

	private:
		void WriteEventToFile(core::MessageEvent* event);
		void updateSequeneID(core::MessageEvent* event);
	private:
		MessageTranslator _translator;
		std::ofstream _outFileStream;
		MessageSequenceProcessor _sequenceProcessor;
	};
}
