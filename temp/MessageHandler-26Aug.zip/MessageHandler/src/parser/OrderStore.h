#pragma once

#include "Service.h"
#include <unordered_map>
#include  "OrderMessage.h"
#include <memory>

using MessagePtr = std::unique_ptr<messages::OrderMessage>;


namespace parser {

	using OrderPtr = std::unique_ptr<messages::Order>;
	class OrderStore {
	public:
		OrderStore();
		void process(MessagePtr& messagePtr);
	private:
		std::unordered_map<uint64_t, OrderPtr> _orderStore;
	};
}
