#pragma once

#include "Service.h"
#include <unordered_map>
#include  "OrderMessage.h"
#include <memory>

using MessagePtr = std::unique_ptr<messages::OrderMessage>;


namespace parser {
	/* OrderStore
	*
	* Helps for Original Order Reference for Cancel, Execute and Replace messages
	*
	*/
	using OrderPtr = std::unique_ptr<messages::Order>;
	class OrderStore {
	public:
		OrderStore() noexcept;
		void process(MessagePtr& messagePtr) noexcept;
	private:
		std::unordered_map<uint64_t, OrderPtr> _orderStore;
	};
}
