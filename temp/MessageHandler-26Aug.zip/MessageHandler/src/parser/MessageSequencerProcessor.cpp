#include "MessageSequenceProcessor.h"

namespace parser {
	MessageSequenceProcessor::MessageSequenceProcessor() noexcept
		:_currentSequenceId(0) 
	{
	}

	bool MessageSequenceProcessor::IsMessageToBeProcessed(core::MessageEvent* event) noexcept
	{
		if (_currentSequenceId + 1 == event->SequenceID)
		{
			++_currentSequenceId;
			return true;
		}
		else
		{
			// we have to hold it till it arrives in sequece;
			_sequenceTable[event->SequenceID] = event;
			return false;
		}

	}
	
	core::MessageEvent* MessageSequenceProcessor::CheckIfPendingMessageCanBeProcessed() noexcept
	{
		core::MessageEvent* msg= nullptr;
		if (_sequenceTable.size() > 0) {
			if (_currentSequenceId + 1 == _sequenceTable.begin()->first)
			{
				auto messageIter = _sequenceTable.begin();
				msg = messageIter->second;
				_sequenceTable.erase(messageIter);
			}
		}
		return msg;
	}

}

