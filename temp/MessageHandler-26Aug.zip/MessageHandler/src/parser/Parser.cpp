#include "Parser.h"
#include <iostream>
#include  "ByteStream.h"
#include  "OrderMessage.h"
#include <fstream>
#include <string>
#include <cstdio>
#include  "MessageProcessor.h"


Parser::Parser(int date, const std::string &outputFilename,bool async)
:_pool(1000), // preallocate Message events for performance reasons.
_processor(outputFilename,async)
{
	_processor.Start();
}

Parser::~Parser()
{
	_processor.Stop();
}
void Parser::onUDPPacket(const char *buf, size_t len)
{
	//printf("Received packet of size %zu\n", len);
	
	auto messageEventPtr = _pool.Allocate();
	messageEventPtr->Init(buf,len);
	_processor.Post(messageEventPtr);
	_pool.Deallocate(messageEventPtr);
}



