#pragma once

#include "Service.h"
#include <unordered_map>
#include  "OrderMessage.h"
#include  "OrderStore.h"
#include <memory>

namespace parser {
	/* MessageTranslator
	*
	* Translates In Binary stream - > OrderMessage -> Out Binary Stream
	*
	*/
	class MessageTranslator  {
	public:
		MessageTranslator() noexcept;
		void Translate(core::MessageEvent* event);
	private:
		std::unordered_map<char, MessagePtr> _messageSerializers;
		OrderStore _orderStore;
	};
}
