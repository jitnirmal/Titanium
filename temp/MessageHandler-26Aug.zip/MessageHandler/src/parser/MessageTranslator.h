#pragma once

#include "Service.h"
#include <unordered_map>
#include  "OrderMessage.h"
#include  "OrderStore.h"
#include <memory>

namespace parser {
	class MessageTranslator  {
	public:
		MessageTranslator();
		void Translate(core::MessageEvent* event);
	private:
		std::unordered_map<char, MessagePtr> _messageSerializers;
		OrderStore _orderStore;
	};
}
