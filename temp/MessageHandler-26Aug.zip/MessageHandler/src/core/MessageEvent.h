#pragma once
#include <cstring>

namespace core {
	constexpr uint16_t MAX_MESSAGE_SIZE = 100;

	struct MessageEvent
	{
		void Init(const char* buffer, size_t len, long sqID = -1)
		{
			Length = len;
			std::memcpy(&Data, buffer, len);
			SequenceID = sqID;
		}

		char Data[MAX_MESSAGE_SIZE];
		size_t Length;
		long SequenceID;
	};
}
