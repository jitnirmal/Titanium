#pragma once
#include <cstring>
#include <stdexcept>

namespace core {
	/* Message Event
	*
	* Struct to Handle Message Events.
	*
	*/

	constexpr uint16_t MAX_MESSAGE_SIZE = 100;

	struct MessageEvent
	{
		/* MessageEvent
		*
		* Init is invoked to copy the received Packet Buffer
		*
		*/

		void Init(const char* buffer, size_t len, long sqID = -1)
		{
			Length = len;
			std::memcpy(&Data, buffer, len);
			SequenceID = sqID;
		}

		char Data[MAX_MESSAGE_SIZE];
		size_t Length;
		long SequenceID;
	};

	class BufferOverflowError : public std::overflow_error
	{
	public:
		BufferOverflowError(const char* message) :
			overflow_error(message)
		{}
	};
}

	
