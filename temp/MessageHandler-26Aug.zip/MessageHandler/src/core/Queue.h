#pragma once

#include <deque>
#include <thread>
#include <mutex>
#include <condition_variable>

namespace core {
	/* Queue
	*
	* Thread Safe Queue to decouple client threads from event processing
	* It is optimized for Single Producer, Single consumer
	* Swapable buffer allows consumer to process events in batch
	*
	*/
	template<typename Data>
	class Queue {
		using queue_lock = std::unique_lock<std::mutex>;

	public:
		Queue()
			: _queue1(new std::deque<Data>()),
			_queue2(new std::deque<Data>())
		{}
		
		//disable copy and assignment
		Queue(Queue const &) = delete;
		Queue& operator=(Queue const&) = delete;

		virtual ~Queue()
		{
			delete _queue1;
			delete _queue2;
		}
		/* enqueue
		*
		* Enqueue the events in queue
		*
		*/
		void enqueue(const Data& data)
		{
			queue_lock lock(_mutex);
			_queue1->push_back(data);
			_signalItemAdded.notify_one();
		}

		/* enqueue
		*
		* Enqueue the events in queue (rvalue)
		*
		*/
		void enqueue(Data&& data)
		{
			queue_lock lock(_mutex);
			_queue1->push_back(std::move(data));
			_signalItemAdded.notify_one();
		}
		/* dequeue
		*
		* dequeu the events in queue 
		* Till consume queue is not empty no lock. Specialized for Single consumer
		*/
		Data dequeue()
		{
			if (_queue2->empty())
			{
				queue_lock lock(_mutex);
				_signalItemAdded.wait(lock, [&] {return !(_queue1->empty()); });
				std::swap(_queue1, _queue2);
			}
			Data t = std::move(_queue2->front());
			_queue2->pop_front();
			return t;
		}

		bool empty() 
		{
			queue_lock lock(_mutex);
			return (_queue1->empty() && _queue2->empty());
		}
	private:
		std::deque<Data>*            _queue1;
		std::deque<Data>*            _queue2;
		std::mutex					_mutex;
		std::condition_variable		_signalItemAdded;

	};
}
