#pragma once

#include <deque>
#include <thread>
#include <mutex>
#include <vector>
#include <condition_variable>
namespace core {

	template<typename Data>
	class BlockingQ {
	private:
		std::deque<Data>*            _queue1;
		std::deque<Data>*            _queue2;
		std::mutex					_mutex;

		std::condition_variable		_signalItemAdded;
		using queue_lock = std::unique_lock<std::mutex>;

	public:
		BlockingQ()
			: _queue1(new std::deque<Data>()),
			_queue2(new std::deque<Data>())
		{}
		virtual ~BlockingQ()
		{
			delete _queue1;
			delete _queue2;
		}

		void enqueue(const Data& data)
		{
			queue_lock lock(_mutex);
			_queue1->push_back(data);
			_signalItemAdded.notify_one();
		}

		void enqueue(Data&& data)
		{
			queue_lock lock(_mutex);
			_queue1->push_back(std::move(data));
			_signalItemAdded.notify_one();
		}

		Data dequeue()
		{
			if (_queue2->empty())
			{
				queue_lock lock(_mutex);
				_signalItemAdded.wait(lock, [&] {return !(_queue1->empty()); });
				std::swap(_queue1, _queue2);
			}
			Data t = std::move(_queue2->front());
			_queue2->pop_front();
			return t;
		}

		bool empty() 
		{
			queue_lock lock(_mutex);
			return (_queue1->empty() && _queue2->empty());
		}

	};
}
