#include "Utils.h"
#include <chrono>
namespace core {

	uint64_t getTimeStampI64()
	{
		return std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count();
	}


}
