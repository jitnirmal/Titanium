#pragma once
#include <cstdint>
#include <string>


namespace core {

	uint64_t getTimeStampI64();

}
