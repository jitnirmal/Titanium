#pragma once
#include <cstdint>

namespace core {

	uint64_t getTimeStampI64();

}
