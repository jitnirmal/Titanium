#pragma once
#include <iostream>
namespace core
{
	/* SingletonBase
	*
	* assists to create Singleton Objects
	*/
	template <class T>
	class SingletonBase
	{
	protected:
		SingletonBase() {}
	public:
		SingletonBase(SingletonBase const &) = delete;
		SingletonBase& operator=(SingletonBase const&) = delete;
		static T& instance()
		{
			static T single;
			return single;
		}
	};

}
