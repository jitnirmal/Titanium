#pragma once
#include <deque>
#include <thread>
#include <mutex>

namespace core {
	/* Memory Pool
	*
	* Memory Pool is thread safe implementation to save expensive heap allocations
	*
	*/

template <typename T>
class MemoryPool 
{
	public:
		using pool_lock = std::unique_lock<std::mutex>;

		/* Allocate
		*
		* Allocates returns available objects from the pool
		* If the preallocated objects are all used up, it allocates then using new
		*
		*/

		MemoryPool() = delete;
		/* MemoryPool
		*
		* Constructor that preallocate numOfRecords to avoid performance penalities
		*
		*/
		MemoryPool(size_t numOfRecords) :
			_block(nullptr),
			_numOfRecords(numOfRecords)
		{
			for (size_t i = 0; i < numOfRecords; ++i)
			{
				auto ptr = new T();
				_freeList.push_back(ptr);
			}

		}
		
		~MemoryPool()
		{
			Flush();
		}


		/* Allocate 
		*
		* Allocates returns available objects from the pool(freeList)
		* If the preallocated objects are all used up, it allocates then using new
		*
		*/

		inline T* Allocate()
		{
			T* ptr = nullptr;
			{
				pool_lock lock(_mutex);
				if (!_freeList.empty())
				{
					ptr = _freeList.front();
					_freeList.pop_front();
					return ptr;
				}
			}
			ptr = new T();
			return ptr;
		}

		/* Deallocate
		*
		*  returns object back to pool(freeList)
		*
		*/
		inline void Deallocate(T* ptr)
		{
			pool_lock lock(_mutex);
			_freeList.push_front(ptr);
		}
private:
		/* Deallocate
		*
		*  Cleanup for used memory
		*
		*/
		inline void Flush()
		{
			for (auto& ptr : _freeList)
			{
				delete ptr;
			}
			_freeList.clear();
		}

	private:
		char* _block;
		size_t _numOfRecords;
		std::deque<T*> _freeList;
		std::mutex	_mutex;

	};
}