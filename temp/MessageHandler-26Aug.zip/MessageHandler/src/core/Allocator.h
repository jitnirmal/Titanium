#pragma once
#include <deque>
#include <thread>
#include <mutex>

namespace core {

template <typename T>
class MemoryPool
{
	public:
		using pool_lock = std::unique_lock<std::mutex>;

		MemoryPool(size_t numOfRecords) :
			_block(nullptr),
			_numOfRecords(numOfRecords)
		{
			for (size_t i = 0; i < numOfRecords; ++i)
			{
				auto ptr = new T();
				_freeList.push_back(ptr);
			}

		}

		inline T* allocate()
		{
			T* ptr = nullptr;
			{
				pool_lock lock(_mutex);
				if (!_freeList.empty())
				{
					ptr = _freeList.front();
					_freeList.pop_front();
					return ptr;
				}
			}
			ptr = new T();
			return ptr;
		}

		inline void deallocate(T* ptr)
		{
			pool_lock lock(_mutex);
			_freeList.push_front(ptr);
		}

		inline void flush()
		{
			for (auto& ptr : _freeList)
			{
				delete ptr;
			}
			_freeList.clear();
		}

	private:
		char* _block;
		size_t _numOfRecords;
		std::deque<T*> _freeList;
		std::mutex	_mutex;

	};
}