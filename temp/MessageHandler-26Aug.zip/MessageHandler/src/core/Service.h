#pragma once
#include <thread>
#include <mutex>
#include "Queue.h"
#include "Singleton.h"
#include "MessageEvent.h"

namespace core {

	/* Service
	*
	* Service to decouple the Event incoprocessing in seperate thread. 
	* It can run in 2 modes 
		a) ASync = false - Does not create new thread. OnMessageUpdate is processed on client thread
		b) ASync = true - Creates new thread. Client invokes Post menthod to handover events for processing on different thread.
	*/

	class Service {
	public:
		
		explicit Service(std::string name, bool async ) noexcept
			: _name(name) ,
			_async(async)
		{
		}
		
		//disable copy and assignment
		Service(Service const &) = delete;
		Service& operator=(Service const&) = delete;

		virtual ~Service() noexcept {
			
		}
	
		void Start() {
			if (_async)
			{
				_thread = std::thread(&Service::run, this);
				_thread.detach();
			}
		}

		void Stop() {
			if (_async)
			{
				while (_queue.empty() == false)
				{
					//printf("Waiting for Queue Processing..\n");
					using namespace std::chrono_literals;
					std::this_thread::sleep_for(10ms);
				}
			}
		}
		
		/* Post
		*
		* Client invoke to use Service async mode
		*
		*/
		void Post(MessageEvent* event) {
			if (_async)
			{
				_queue.enqueue(event);
			}
			else
			{
				OnMessageUpdate(event);
			}
		}

		/* Post - 
		* Abstract, Must be overriden by subclasses
		*
		*/
		virtual void OnMessageUpdate(MessageEvent* event) = 0;

	private:
		void run() {
			try {
				while (true) {
					auto messageEvt = _queue.dequeue();
					OnMessageUpdate(messageEvt);
				}
			}
			catch (const std::exception& ex) {
				std::cout << "exception happened - " << ex.what() << "\n";
			}
			catch (...) {
				std::cout << "unexception happened - " << "\n";
			}
		}
	private:
		std::string						_name;
		std::thread						_thread;
		Queue<MessageEvent*>			_queue;
		bool							_async;
	};




}
