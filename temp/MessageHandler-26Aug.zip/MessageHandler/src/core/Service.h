#pragma once
#include <thread>
#include <mutex>
#include "Queue.h"
#include "Singleton.h"
#include "MessageEvent.h"

namespace core {



	class Service :public SingletonBase <Service>{
	public:
		Service(std::string name) : _name(name), _firstEvent(true){}

		~Service() {
			
		}

		bool Start() {
			_thread = std::thread(&Service::run, this);
			_thread.detach();
			return true;
		}

		bool Stop() {
			while (_queue.empty() == false)
			{
				//printf("Waiting for Queue Processing..\n");
				using namespace std::chrono_literals;
				std::this_thread::sleep_for(10ms);
			}
			
			auto end = std::chrono::high_resolution_clock::now();
			auto diff = end - _start;

		//	printf("Stopping now..Time Taken %u\n", diff.count());
			return true;
		}
		
		bool Post(MessageEvent* event) {
			if (_firstEvent == true)
			{
				_start = std::chrono::high_resolution_clock::now();
				_firstEvent = false;
			}
			_queue.enqueue(event);
			return true;
		}

		virtual void onMessageUpdate(MessageEvent* event) = 0;
	private:
		void run() {
			try {
				while (true) {
					auto messageEvt = _queue.dequeue();
					onMessageUpdate(messageEvt);
				}
			}
			catch (...) {
				printf("Caught exception....\n");
			}
		}
	private:
		std::string							_name;
		std::thread							_thread;
		BlockingQ<MessageEvent*>			_queue;
		std::chrono::high_resolution_clock::time_point _start;
		bool _firstEvent;
	};




}
