#pragma once
#include <cstdint>
#include "ByteStream.h"
#include "OrderMessage.h"
#include "Endian.h"

namespace messages {

	static const uint8_t  AddOrderMessageSizeIn { 34 };
	static const uint8_t  AddOrderMessageSizeOut { 44 };

	class AddOrderMessage : public OrderMessage {
	private:
	public:
		AddOrderMessage():OrderMessage('A'){}
		virtual uint16_t ReadByteStreamIn(ReadByteBuffer& buffer) override
		{
			MsgType = buffer.read<char>();
			_order.Timestamp =  buffer.read<uint64_t>(true);
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
			_order.Side = buffer.read<char>();
			_order.Size = buffer.read<uint32_t>(true);
			
			buffer.readBytes(_order.StockTicker, sizeof(_order.StockTicker));
			//rtrim(_order.StockTicker);

			setPriceI32(buffer.read<uint32_t>(true));
			return buffer.GetByteCount();

		}
		virtual uint16_t WriteByteStreamIn(WriteByteBuffer& buffer) override
		{
			buffer.append(MsgType);
			buffer.append(_order.Timestamp, true);
			buffer.append(_order.OrderReferenceNumber, true);
			buffer.append(_order.Side);
			buffer.append(_order.Size, true);

			//padWithSpace(_order.StockTicker);
			buffer.appendBytes(_order.StockTicker, sizeof(_order.StockTicker));
			buffer.append(getPriceI32(), true);
			return buffer.GetByteCount();
		}
		virtual uint16_t ReadByteStreamOut(ReadByteBuffer& buffer) override
		{
			

			uint16_t msgType = buffer.read<uint16_t>();
			uint16_t msgSize = buffer.read<uint16_t>(true);
		
			buffer.readBytes(_order.StockTicker, sizeof(_order.StockTicker));
			_order.Timestamp = buffer.read<uint64_t>(true);
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
			_order.Side = buffer.read<char>();
			
			// skip the padding space
			buffer.read<char>();
			buffer.read<char>();
			buffer.read<char>();

			_order.Size = buffer.read<uint32_t>(true);
			auto price = buffer.read<uint64_t>(true);
			setPriceI64(price);
			return buffer.GetByteCount();
		}
		virtual uint16_t WriteByteStreamOut(WriteByteBuffer& buffer) override
		{
			uint16_t msgType = 0x01;
			buffer.append(msgType);

			uint16_t msgSize = AddOrderMessageSizeOut ;
			buffer.append(msgSize, true);

			buffer.appendBytes(_order.StockTicker, sizeof(_order.StockTicker));
			buffer.append(_order.Timestamp, true);
			
			buffer.append(_order.OrderReferenceNumber, true);
			buffer.append(_order.Side);

			buffer.append('0');
			buffer.append('0');
			buffer.append('0');
			
			buffer.append(_order.Size, true);
			auto price = getPriceI64();
			buffer.append(price, true);
			return buffer.GetByteCount();
		}

	};
}