#pragma once
#include <cstdint>
#include "ByteStream.h"
#include "OrderMessage.h"
#include "Endian.h"

namespace messages {

	constexpr  uint16_t  AddOrderMessageSizeIn { 34 };
	constexpr  uint16_t  AddOrderMessageSizeOut { 44 };
	/* AddOrderMessage
	*
	* Base class for binary stream operations
	*
	*/
	class AddOrderMessage : public OrderMessage {
	private:
	public:
		AddOrderMessage();
		virtual size_t ReadByteStreamIn(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamIn(WriteByteBuffer& buffer) override;
		virtual size_t ReadByteStreamOut(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamOut(WriteByteBuffer& buffer) override;
	};
}