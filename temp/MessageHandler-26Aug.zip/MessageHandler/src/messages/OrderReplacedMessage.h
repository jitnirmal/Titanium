#pragma once
#include "OrderMessage.h"
namespace messages {
	
	constexpr  uint16_t  OrderReplacedMessageSizeIn{ 33 };
	constexpr  uint16_t  OrderReplacedMessageSizeOut{ 48 };

	class OrderReplacedMessage : public OrderMessage {
	private:
		uint64_t NewOrderReferenceNumber;
	public:
		OrderReplacedMessage();
	
		inline void setNewOrderReferenceNumber(uint64_t newOrderReferenceNumber) {
			NewOrderReferenceNumber = newOrderReferenceNumber;
		}
		inline uint64_t getNewOrderReferenceNumber() const {
			return NewOrderReferenceNumber;
		}
		
		virtual size_t ReadByteStreamIn(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamIn(WriteByteBuffer& buffer) override;
		virtual size_t ReadByteStreamOut(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamOut(WriteByteBuffer& buffer) override;
	};
}