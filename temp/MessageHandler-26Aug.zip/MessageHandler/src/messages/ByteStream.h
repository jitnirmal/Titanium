#pragma once
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <memory>
#include "Endian.h"
namespace messages {
	
	class ByteBuffer {
	public:
		ByteBuffer(char* strm, const uint16_t size)
			:pos(0),
			stream(strm),
			SIZE(size) {}
		
		uint16_t GetByteCount() const {
			return pos;
		}

		void Reset(char* strm, const uint16_t size)
		{
			pos = 0;
			stream = strm;
			SIZE=size;
		}

	protected:
		uint16_t pos;
		uint16_t SIZE;
		char* stream;
	};

	class WriteByteBuffer :public ByteBuffer {
	public:
		WriteByteBuffer(char* stream, const uint16_t size)
			:ByteBuffer(stream, size) {}

		template <typename T>
		void append(T data, bool swapEndian = false) {
			auto dataSize = sizeof(data);
			if ((pos + dataSize) > SIZE)
				return;
			
			T loc_data;
			if (swapEndian == true)	{
				loc_data = swap_endian(data);
			}
			else
			{
				loc_data = data;
			}
			memcpy(&stream[pos], (uint8_t*)&loc_data, dataSize);
			pos = pos + dataSize;
		}

		void appendBytes(char* b, uint32_t len) {
			for (uint32_t i = 0; i < len; i++)
				append<char>(b[i]);
		}
	};

	class ReadByteBuffer :public ByteBuffer {
	public:
		ReadByteBuffer(char* stream, const uint16_t size)
			:ByteBuffer(stream, size) {}



		template<typename T>
		T read(bool swapEndian = false) {
			if (pos + sizeof(T) <= SIZE)
			{
				auto temp_pos = pos;
				pos = pos + sizeof(T);
				if (swapEndian == true) 
				{
					return swap_endian(*((T*)&stream[temp_pos]));
				}
				else
				{
					return *((T*)&stream[temp_pos]);
				}
				
			}
			return 0;
		}

		void readBytes(char* buf, uint32_t len)  {
			for (uint32_t i = 0; i < len; i++) {
				buf[i] = read<char>();
			}
		}
	};
}