#pragma once
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <memory>
#include "Endian.h"
#include "MessageEvent.h"

namespace messages {
	/* ByteBuffer
	*
	* Base class for binary stream operations
	*
	*/
	class ByteBuffer {
	public:
		explicit ByteBuffer(char* strm, const size_t sz) noexcept
			:_pos(0),
			_stream(strm),
			_size(sz) {}
		
		//disable copy and assignment of Byte Buffer
		ByteBuffer(ByteBuffer const &) = delete;
		ByteBuffer& operator=(ByteBuffer const&) = delete;

		inline size_t GetByteCount() const noexcept {
			return _pos;
		}

		inline void Reset(char* strm, const size_t sz) noexcept
		{
			_pos = 0;
			_stream = strm;
			_size = sz;
		}

	protected:
		size_t _pos;
		size_t _size;
		char* _stream;
	};

	/* WriteByteBuffer
	*
	* provides append functions.
	*
	*/

	class WriteByteBuffer :public ByteBuffer {
	public:
		WriteByteBuffer(char* stream, const size_t size)
			:ByteBuffer(stream, size) {}

		template <typename T>
		void append(T data, bool swapEndian = false)  {
			auto dataSize = sizeof(data);
			if ((_pos + dataSize) > _size)
			{
				throw core::BufferOverflowError("WriteStream Size Overflow");
			}
			
			T loc_data;
			if (swapEndian == true)	{
				loc_data = swap_endian(data);
			}
			else
			{
				loc_data = data;
			}
			memcpy(&_stream[_pos], (uint8_t*)&loc_data, dataSize);
			_pos = _pos + dataSize;
		}

		void appendBytes(char* b, const size_t len) {
			for (size_t i = 0; i < len; i++)
				append<char>(b[i]);
		}
	};

	/* WriteByteBuffer
	*
	* provides read functions.
	*
	*/

	class ReadByteBuffer :public ByteBuffer {
	public:
		ReadByteBuffer(char* stream, const size_t size)
			:ByteBuffer(stream, size) {}



		template<typename T>
		T read(bool swapEndian = false)  {
			if (_pos + sizeof(T) > _size) 
			{
				throw core::BufferOverflowError("ReadStream Size Overflow");
			}
			
			auto temp_pos = _pos;
			_pos = _pos + sizeof(T);
			if (swapEndian == true)
			{
				return swap_endian(*((T*)&_stream[temp_pos]));
			}
			else
			{
				return *((T*)&_stream[temp_pos]);
			}
				
			return 0;
		}

		void readBytes(char* buf, const size_t len)  {
			for (size_t i = 0; i < len; i++) {
				buf[i] = read<char>();
			}
		}
	};
}