#include "OrderCancelledMessage.h"

namespace messages {
	
		OrderCancelledMessage::OrderCancelledMessage()
		: OrderMessage('C') {
		}

		size_t OrderCancelledMessage::ReadByteStreamIn(ReadByteBuffer& buffer) 
		{
			MsgType = buffer.read<char>();
			_order.Timestamp = buffer.read<uint64_t>(true);
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
			_order.Size = buffer.read<uint32_t>(true);
			return buffer.GetByteCount();

		}
		size_t OrderCancelledMessage::WriteByteStreamIn(WriteByteBuffer& buffer)
		{
			buffer.append(MsgType);
			buffer.append(_order.Timestamp, true);
			buffer.append(_order.OrderReferenceNumber, true);
			buffer.append(_order.Size, true);
			return buffer.GetByteCount();
		}
		size_t OrderCancelledMessage::ReadByteStreamOut(ReadByteBuffer& buffer)
		{
			uint16_t msgType = buffer.read<uint16_t>();
			uint16_t msgSize = buffer.read<uint16_t>(true);
			buffer.readBytes(_order.StockTicker, sizeof(_order.StockTicker));

			_order.Timestamp = buffer.read<uint64_t>(true);
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
		
			_order.Size = buffer.read<uint32_t>(true);
			return buffer.GetByteCount();
		}
		size_t OrderCancelledMessage::WriteByteStreamOut(WriteByteBuffer& buffer)
		{
			uint16_t msgType = 0x03;
			buffer.append(msgType);

			uint16_t msgSize = OrderCancelledMessageOut;
			
			buffer.append(msgSize, true);

			buffer.appendBytes(_order.StockTicker, sizeof(_order.StockTicker));

			buffer.append(_order.Timestamp, true);

			buffer.append(_order.OrderReferenceNumber, true);

			buffer.append(_order.Size, true);

			return buffer.GetByteCount();
		}

}