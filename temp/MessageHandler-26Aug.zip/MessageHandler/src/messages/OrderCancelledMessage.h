#pragma once
#include "OrderMessage.h"
namespace messages {
	
	constexpr  uint16_t  OrderCancelledMessageSizeIn{ 21 };
	constexpr  uint16_t  OrderCancelledMessageOut{ 32 };

	struct OrderCancelledMessage :  public OrderMessage{
	public:
		OrderCancelledMessage();
		virtual size_t ReadByteStreamIn(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamIn(WriteByteBuffer& buffer) override;
		virtual size_t ReadByteStreamOut(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamOut(WriteByteBuffer& buffer) override;
	};
}