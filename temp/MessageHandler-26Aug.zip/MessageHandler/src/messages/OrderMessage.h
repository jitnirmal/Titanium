#pragma once

#include <cstdint>
#include "ByteStream.h"
namespace messages {
	
	

	static const uint8_t  HeaderMessageSizeIn { 4 };
	static const uint8_t  HeaderMessageSizeOut { 2 };
	static const int  PRICE_MULT{ 10000 };

	struct Order 
	{
		uint64_t Timestamp;
		uint64_t OrderReferenceNumber;
		char StockTicker[8];
		double Price;
		char Side;
		uint32_t Size;

		inline uint32_t getPriceI32() const {
			return uint32_t(Price * PRICE_MULT);
		}
	};

	class OrderMessage
	{
	public:
		OrderMessage(char msgType) :MsgType(msgType) {}
		virtual uint16_t ReadByteStreamIn(ReadByteBuffer& buffer) = 0;
		virtual uint16_t WriteByteStreamIn(WriteByteBuffer& buffer) = 0;
		virtual uint16_t ReadByteStreamOut(ReadByteBuffer& buffer) = 0;
		virtual uint16_t WriteByteStreamOut(WriteByteBuffer& buffer) = 0;

		inline const Order& getOrder() const {
			return _order;
		}

		inline char getMsgType() const {
			return MsgType;
		}

		inline void setTimestamp(uint64_t timestamp) {
			_order.Timestamp = timestamp;
		}
		inline uint64_t getTimestamp() const {
			return _order.Timestamp;
		}

		inline void setOrderReferenceNumber(uint64_t orderReferenceNumber) {
			_order.OrderReferenceNumber = orderReferenceNumber;
		}
		inline uint64_t getOrderReferenceNumber() const {
			return _order.OrderReferenceNumber;
		}
		inline void setStockTicker(const char* ticker) {
			snprintf(_order.StockTicker, sizeof(_order.StockTicker), "%s", ticker);
		}
		inline const char* getStockTicker() const {
			return _order.StockTicker;
		}
		
		inline void setPriceI64(uint64_t price) {
			_order.Price = double(price)/ PRICE_MULT;
		}
		inline uint64_t getPriceI64() const {
			return uint64_t(_order.Price * PRICE_MULT);
		}

		inline void setPriceI32(uint32_t price) {
			_order.Price = double(price) / PRICE_MULT;
		}
		inline uint32_t getPriceI32() const {
			return uint32_t(_order.Price * PRICE_MULT);
		}


		

		inline void setSide(char side) {
			_order.Side = side;
		}
		inline char getSide() const {
			return _order.Side;
		}

		inline void setSize(uint32_t size) {
			_order.Size = size;
		}
		inline uint32_t getSize() const {
			return _order.Size;
		}

	protected:
		char MsgType;
		Order _order;
	};

}