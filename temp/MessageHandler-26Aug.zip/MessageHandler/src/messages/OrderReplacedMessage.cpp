#include "OrderReplacedMessage.h"
namespace messages {

		OrderReplacedMessage::OrderReplacedMessage()
			:OrderMessage('R') {}
	

		size_t OrderReplacedMessage::ReadByteStreamIn(ReadByteBuffer& buffer) 
		{
			MsgType = buffer.read<char>();
			_order.Timestamp = buffer.read<uint64_t>(true);
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
			NewOrderReferenceNumber = buffer.read<uint64_t>(true);
			_order.Size = buffer.read<uint32_t>(true);
			setPriceI32(buffer.read<uint32_t>(true));
			return buffer.GetByteCount();

		}
		size_t OrderReplacedMessage::WriteByteStreamIn(WriteByteBuffer& buffer) 
		{
			buffer.append(MsgType);
			buffer.append(_order.Timestamp, true);
			buffer.append(_order.OrderReferenceNumber, true);
			buffer.append(NewOrderReferenceNumber, true);
			buffer.append(_order.Size, true);
			buffer.append(getPriceI32(), true);
			return buffer.GetByteCount();
		}

		size_t OrderReplacedMessage::ReadByteStreamOut(ReadByteBuffer& buffer) 
		{
			uint16_t msgType = buffer.read<uint16_t>();
			
			uint16_t msgSize = buffer.read<uint16_t>(true);

			buffer.readBytes(_order.StockTicker, sizeof(_order.StockTicker));
			
			_order.Timestamp = buffer.read<uint64_t>(true);
			
			_order.OrderReferenceNumber = buffer.read<uint64_t>(true);
			
			NewOrderReferenceNumber = buffer.read<uint64_t>(true);
		
			_order.Size = buffer.read<uint32_t>(true);
			
			setPriceI64(buffer.read<uint64_t>(true));
			
			return buffer.GetByteCount();
		}

	    size_t OrderReplacedMessage::WriteByteStreamOut(WriteByteBuffer& buffer) 
		{
			uint16_t msgType = 0x04;
			buffer.append(msgType);

			uint16_t msgSize = OrderReplacedMessageSizeOut;
			buffer.append(msgSize, true);

			buffer.appendBytes(_order.StockTicker, sizeof(_order.StockTicker));
			
			buffer.append(_order.Timestamp, true);

			buffer.append(_order.OrderReferenceNumber, true);
			
			buffer.append(NewOrderReferenceNumber, true);
		
			buffer.append(_order.Size, true);

			buffer.append(getPriceI64(), true);

			return buffer.GetByteCount();
		}
}