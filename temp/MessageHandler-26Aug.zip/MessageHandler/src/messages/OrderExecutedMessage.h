#pragma once
#include "OrderMessage.h"

namespace messages {
	constexpr  uint16_t  OrderExecutedMessageSizeIn{ 21 };
	constexpr  uint16_t  OrderExecutedMessageOut{ 40 };

	class OrderExecutedMessage : public OrderMessage{
	public:
		OrderExecutedMessage();
		virtual size_t ReadByteStreamIn(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamIn(WriteByteBuffer& buffer) override;
		virtual size_t ReadByteStreamOut(ReadByteBuffer& buffer) override;
		virtual size_t WriteByteStreamOut(WriteByteBuffer& buffer) override;
		
	};
}