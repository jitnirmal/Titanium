#include <iostream>
#include  "ByteStream.h"
#include  "Parser.h"
#include <string>

std::string Infile = ".\\test.in";
std::string outfile = "F:\\2018\\Coding\\Challenge\\Hudson\\MesageParser\\data\\binary_out_test_sec.bin";


void processFileMessages()
{
	Parser parser(20180812, outfile);
	int x;

	std::ifstream infile;
	infile.open(Infile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char Header[500];
		char MessageBuffer[500];
		while (!infile.eof())
		{
			infile.read(Header, 2);
			messages::ReadByteBuffer rbyteBufferHeader(Header, sizeof(Header));
			auto packetSize = rbyteBufferHeader.read<uint16_t>(true);
			
			infile.read(MessageBuffer, packetSize-2);
			parser.onUDPPacket(MessageBuffer, packetSize);
		}
	}
}



int main()
{
	processFileMessages();
	std::cout << "Enter any character to exit !!" << std::endl;
	int c;
	std::cin >> c;

}