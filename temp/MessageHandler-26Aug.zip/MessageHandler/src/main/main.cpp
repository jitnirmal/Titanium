#include <iostream>
#include  "ByteStream.h"
#include  "Parser.h"
#include  "Utils.h"
#include <string>

std::string main_Infile = "C:\\Users\\jitni\\Data\\test.in";
std::string main_Outfile = "C:\\Users\\jitni\\Data\\test.out";


void processFileMessages()
{
	Parser parser(20180812, main_Outfile);
	int x;

	std::ifstream infile;
	infile.open(main_Infile.c_str(), std::ios::binary | std::ios::in);
	if (infile.is_open())
	{
		char Header[500];
		char MessageBuffer[500];
		while (!infile.eof())
		{
			infile.read(Header, 2);
			messages::ReadByteBuffer rbyteBufferHeader(Header, sizeof(Header));
			auto packetSize = rbyteBufferHeader.read<uint16_t>(true);
			
			infile.read(MessageBuffer, packetSize-2);
			parser.onUDPPacket(MessageBuffer, packetSize);
		}
	}
	else {
		std::cout << "Not able to open the file !!" << std::endl;
	}
}



int main()
{
	processFileMessages();
	std::cout << "Enter any character to exit !!" << std::endl;
	int c;
	std::cin >> c;

}