#!/usr/bin/env bash
set -e
mkdir build || true
cd build
cmake ..
make
./bin/testParser.exe