#include "ThrottleControl.h"
#include <time.h>
#include <thread>
#include <iostream>
#include <chrono>

void submitRequest(ThrottleControl& t, const int requestId)
{
	if (t.CanSubmitRequest())
	{
		t.SubmitRequest();
		std::cout << "[" << requestId << "] " << " submitted " << std::endl;
	}
	else
	{
		auto timeDiff = t.WaitForSecs();
		if (timeDiff != 0.0)
		{
			std::cout << "[" << requestId << "] " << "waiting for " << timeDiff << " secs." << std::endl;
			std::this_thread::sleep_for(std::chrono::milliseconds(int(timeDiff * 1000)));
			submitRequest(t,requestId);
		}
	}
}

int main(int argc, char * argv[])
{
	ThrottleControl t(15,5.0);
	clock_t cbegin = clock();
	for (int i = 1; i < 40; i++)
	{
		submitRequest(t,i);
	}

	clock_t cend = clock();
	std::cout << "Completed. " << double(cend - cbegin) / CLOCKS_PER_SEC << " sec." << std::endl;
	system("pause");
	return 0;
}