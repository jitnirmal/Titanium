#pragma once

#include <ctime>
#include <deque>
#include <iostream>

class ThrottleControl
{
public:
	explicit ThrottleControl(const int rate, double interval) :
		_monitorWindowInSecs(interval), 
		_numOfRequests(rate)
	{ }
	
	~ThrottleControl() 
	{ }

	void SubmitRequest()
	{
		const clock_t now = clock();
		_queue.push_back(now);
	}

	bool CanSubmitRequest() 
	{
		const clock_t now = clock();
		expireTicks(now);

		if (_queue.size() < _numOfRequests) {
			return true;
		}
		return false;
	}

	double WaitForSecs() const 
	{
		const clock_t now = clock();
		double waitFor = 0.0;
		if (_queue.size() >= _numOfRequests)
		{
			waitFor = _monitorWindowInSecs - (double(now - _queue.front()) / CLOCKS_PER_SEC);
		}
		return waitFor;
	}
private:
	void expireTicks(const clock_t& interval)
	{
		while (_queue.size()) {
			auto elaspedTimeInSecs = (double)(interval - _queue.front()) / CLOCKS_PER_SEC;
			
			if (elaspedTimeInSecs >= _monitorWindowInSecs) {
				std::cout << " clearing " << elaspedTimeInSecs << std::endl;
				_queue.pop_front();
			}
			else {
				break;
			}
		}
	}

private:
	const int _numOfRequests;
	double _monitorWindowInSecs;
	std::deque<clock_t> _queue;
};

