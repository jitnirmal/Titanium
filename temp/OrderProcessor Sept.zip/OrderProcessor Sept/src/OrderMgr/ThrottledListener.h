#pragma once
#include "ThrottleControl.h"
#include "Listener.h"

class ThrottledListener : public Listener
{
public:
	ThrottledListener(const unsigned int numOfRequests, const double numOfSecs);

	virtual void OnInsertOrderRequest(
		int id,
		char side, // 'B' for bid, 'O' for offer
		double price,
		int quantity) override ;

	virtual void OnReplaceOrderRequest(
		int oldId, 
		int newId, 
		int deltaQuantity) override;
								
								
	virtual void OnRequestAcknowledged(
		int id) override;
	
	virtual void OnRequestRejected(
		int id) override;
	
	virtual void OnOrderFilled(
		int id,
		int quantityFilled) override;

	inline bool CanSubmitRequest();

	inline double WaitForSecs() const;

private:
	void submitRequest(const int requestId);

private:
	ThrottleControl _throttleControl;
};

inline bool ThrottledListener::CanSubmitRequest() {
	return _throttleControl.CanSubmitRequest();
}

inline double ThrottledListener::WaitForSecs() const {
	return _throttleControl.WaitForSecs();
}