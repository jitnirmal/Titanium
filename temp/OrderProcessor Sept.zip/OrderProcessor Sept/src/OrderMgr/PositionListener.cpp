#pragma once
#include "PositionListener.h"



PositionListener::PositionListener() 
	:NFQ(0)
{}

void PositionListener::updateOrderTable(const int id, const char side, const int& quantity, const double& price) {
	auto orderPtr = new Order(side,quantity,price);
	_orderTable[id] = orderPtr;
}

OrderPtr PositionListener::getOrder(const int id) {
	OrderPtr orderPtr = nullptr;

	const auto& search = _orderTable.find(id);
	if (search != _orderTable.end()) {
		orderPtr = std::move(search->second);
	}
	return orderPtr;
}

void PositionListener::OnInsertOrderRequest(int id, char side, double price, int quantity){
	updateOrderTable(id,side,price,quantity);
	updatePOV(TYPE::MAX,side,price,quantity);
}

void PositionListener::OnReplaceOrderRequest(int oldId, int newId, int deltaQuantity){
	//auto orderPtr = getOrder(id);
	//updateNFQ(orderPtr->Side, quantityFilled);
}
								
void PositionListener::OnRequestAcknowledged(int id){
	auto orderPtr = getOrder(id);
	updateCOV(orderPtr->Side, orderPtr->Quantity, orderPtr->Price);
	updatePOV(TYPE::MIN, orderPtr->Side, orderPtr->Quantity, orderPtr->Price);
}

void PositionListener::OnRequestRejected(int id){
}

void PositionListener::OnOrderFilled(int id,int quantityFilled){
	auto filledQty = (-1)*quantityFilled;

	auto orderPtr = getOrder(id);
	updateNFQ(orderPtr->Side,quantityFilled);
	updateCOV(orderPtr->Side, filledQty, orderPtr->Price);
	updatePOV(TYPE::MIN, orderPtr->Side, filledQty, orderPtr->Price);
}


//Net Filled Quantity(NFQ) : sum of all fill quantities where filled bids count positively and filled offers count negatively.
void PositionListener::updateNFQ(const char side, const int& quantity)
{
	NFQ += (side == 'B') ? quantity : (-1)*quantity;
}


//Confirmed Order Value(COV).Given a side, return the total value of all orders on that side of the market, defined as the product of the
//price and quantity of all orders that have been acknowledged but not fully filled or replaced.
void PositionListener::updateCOV(const char side, const int& quantity, const double& price)
{
	double value = quantity * price;
	if (side == 'B') {
		COV.Bid += value;
	}
	else {
		COV.Ask += value;
	}
}

//Pending Order Value (POV). Given a side, return the minimum and maximum possible total values of all orders on that side of the
//market, taking into account pending requests that have not yet been acknowledged.
void PositionListener::updatePOV(const TYPE type, const char side, const int& quantity, const  double& price)
{
	double value = quantity * price;
	if (side == 'B') {
		if(type == TYPE::MIN)
			POV.Bid.Min += value;
		else
			POV.Bid.Max += value;
	}
	else {
		if (type == TYPE::MIN)
			POV.Ask.Min += value;
		else
			POV.Ask.Max += value;
	}
}