#pragma once
#include "ThrottleControl.h"
#include "Listener.h"
#include <unordered_map>
#include <memory>

using Quantity = long long;

enum class TYPE {
	MIN,
	MAX
};



struct ConfirmedOrderValue {
	ConfirmedOrderValue() :
		Bid(0.0),
		Ask(0.0) {}

	double Bid;
	double Ask;
};

struct Values
{
	Values() :
		Min(0.0),
		Max(0.0) {}
	double Min;
	double Max;
};

struct PendingOrderValue {
	Values Bid;
	Values Ask;
};

struct Order
{
	Order(char side, double price, int quantity) :
		Side(side),
		Price(price),
		Quantity(quantity) {}

	char Side;
	double Price;
	int Quantity;
};

using OrderPtr = Order*;

class PositionListener : public Listener
{
public:
	PositionListener();

	virtual void OnInsertOrderRequest(
		int id,
		char side, // 'B' for bid, 'O' for offer
		double price,
		int quantity) override ;

	virtual void OnReplaceOrderRequest(
		int oldId, 
		int newId, 
		int deltaQuantity) override;
								
								
	virtual void OnRequestAcknowledged(
		int id) override;
	
	virtual void OnRequestRejected(
		int id) override;
	
	virtual void OnOrderFilled(
		int id,
		int quantityFilled) override;
	
	inline Quantity GetNFQ() const;
	inline double GetCOV(const char side) const;
	inline Values GetPOV(const char side) const;

private:
	void updateNFQ(const char side,const int& quantity);
	void updateCOV(const char side, const int& quantity, const double& price);
	void updatePOV(const TYPE type, const char side, const int& quantity, const double& price);

	void updateOrderTable(const int id, const char side, const int& quantity, const double& price);
	OrderPtr getOrder(const int id);

private:
	Quantity NFQ;
	ConfirmedOrderValue COV;
	PendingOrderValue POV;

	std::unordered_map<int, OrderPtr> _orderTable;
};

inline Quantity PositionListener::GetNFQ() const
{
	return NFQ;
}
inline double PositionListener::GetCOV(char side) const
{
	return side == 'B' ? COV.Bid : COV.Ask;
}

inline Values PositionListener::GetPOV(char side) const
{
	return side == 'B' ? POV.Bid : POV.Ask;
}

