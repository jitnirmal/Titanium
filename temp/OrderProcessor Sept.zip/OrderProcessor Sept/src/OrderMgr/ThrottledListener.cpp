#pragma once
#include "ThrottledListener.h"
#include <thread>



ThrottledListener::ThrottledListener(const unsigned int numOfRequests, const double numOfSecs) :
	_throttleControl(numOfRequests, numOfSecs)
{}


void ThrottledListener::OnInsertOrderRequest(int id, char side, double price, int quantity){
	submitRequest(id);
}

void ThrottledListener::OnReplaceOrderRequest(int oldId, int newId, int deltaQuantity){
	submitRequest(newId);
}
								
void ThrottledListener::OnRequestAcknowledged(int id){
}

void ThrottledListener::OnRequestRejected(int id){
}

void ThrottledListener::OnOrderFilled(int id,int quantityFilled){
}

void ThrottledListener::submitRequest(const int requestId)
{
	if (_throttleControl.CanSubmitRequest())
	{
		_throttleControl.SubmitRequest();
		std::cout << "[" << requestId << "] " << " submitted " << std::endl;
	}
	else
	{
		auto timeDiff = _throttleControl.WaitForSecs();
		if (timeDiff != 0.0)
		{
			std::cout << "[" << requestId << "] " << "waiting for " << timeDiff << " secs." << std::endl;
			std::this_thread::sleep_for(std::chrono::milliseconds(int(timeDiff * 1000)));
			submitRequest(requestId);
		}
	}
}