#include <boost/test/unit_test.hpp>
#include "ThrottledListener.h"

BOOST_AUTO_TEST_SUITE(ThrottledListenerTester) 

BOOST_AUTO_TEST_CASE(test1)
{
	
}

BOOST_AUTO_TEST_SUITE_END()