#include <boost/test/unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include "PositionListener.h"

constexpr double TOLERANCE = 0.0001;

BOOST_AUTO_TEST_SUITE(PositionListenerTester) 

BOOST_AUTO_TEST_CASE(TestOnInsertOrderRequest_1)
{
	PositionListener plistener;
	plistener.OnInsertOrderRequest(1, 'B', 10.0, 10);
	
	BOOST_CHECK(plistener.GetNFQ() == 0);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('B'), 0.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('S'), 0.0, TOLERANCE);

	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Max, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Min, 0.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Max, 0.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Min, 0.0, TOLERANCE);

}

BOOST_AUTO_TEST_CASE(TestOnRequestAcknowledged_2)
{
	PositionListener plistener;
	plistener.OnInsertOrderRequest(1, 'B', 10.0, 10);
	plistener.OnRequestAcknowledged(1);

	BOOST_CHECK(plistener.GetNFQ() == 0);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('B'), 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('S'), 0.0, TOLERANCE);

	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Max, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Min, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Max, 0.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Min, 0.0, TOLERANCE);

}

BOOST_AUTO_TEST_CASE(TestOnInsertOrderRequest_3)
{
	PositionListener plistener;
	plistener.OnInsertOrderRequest(1, 'B', 10.0, 10);
	plistener.OnRequestAcknowledged(1);
	plistener.OnInsertOrderRequest(2, 'O', 15.0, 25);

	BOOST_CHECK(plistener.GetNFQ() == 0);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('B'), 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('S'), 0.0, TOLERANCE);

	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Max, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Min, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Max, 375.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Min, 0.0, TOLERANCE);

}

BOOST_AUTO_TEST_CASE(TestOnRequestAcknowledged_4)
{
	PositionListener plistener;
	plistener.OnInsertOrderRequest(1, 'B', 10.0, 10);
	plistener.OnRequestAcknowledged(1);
	plistener.OnInsertOrderRequest(2, 'O', 15.0, 25);
	plistener.OnRequestAcknowledged(2);


	BOOST_CHECK(plistener.GetNFQ() == 0);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('B'), 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('S'), 375.0, TOLERANCE);

	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Min, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Max, 100.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Min, 375.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Max, 375.0, TOLERANCE);
}

BOOST_AUTO_TEST_CASE(TestOnOrderFilled_5)
{
	PositionListener plistener;
	plistener.OnInsertOrderRequest(1, 'B', 10.0, 10);
	plistener.OnRequestAcknowledged(1);
	plistener.OnInsertOrderRequest(2, 'O', 15.0, 25);
	plistener.OnRequestAcknowledged(2);
	plistener.OnOrderFilled(1, 5);

	BOOST_CHECK(plistener.GetNFQ() == 5);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('B'), 50.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetCOV('S'), 375.0, TOLERANCE);

	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Min, 50.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('B').Max, 50.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Min, 375.0, TOLERANCE);
	BOOST_CHECK_CLOSE_FRACTION(plistener.GetPOV('S').Max, 375.0, TOLERANCE);
}

BOOST_AUTO_TEST_SUITE_END()