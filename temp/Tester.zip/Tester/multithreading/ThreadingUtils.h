#pragma once
#include <iostream>
#include <thread>
#include <chrono>
#include "BlockingQueue.h"
#include <future>
#include <atomic>
#include <iostream>




void func(int& x)
{
	try {
		int count{ 0 };
		while (true)
		{
			using namespace std::chrono_literals;
			std::this_thread::sleep_for(1s);
			auto id = std::this_thread::get_id();
			std::cout << "executing thread " << id << " : " << x << std::endl;
			++count;
			if (count == 5)
			{
				throw std::runtime_error("error");
			}
		}
	}
	catch (...)
	{
		std::cout << " unknown error thrown " << std::endl;
	}
}

void TestThread()
{
	auto x = 20;
	//std::thread t;

	// initializing thread with outside function
	std::thread t1(func, std::ref(x));

	// initializing thread with lambda function....
	/*std::thread t2([&]() {
	while (true)
	{
	using namespace std::chrono_literals;
	std::this_thread::sleep_for(1s);
	auto id = std::this_thread::get_id();
	std::cout << "executing thread " << id << " : " << x << std::endl;
	}
	});*/

	t1.join();
	//t2.join();
}

class Object {
public:
	Object(int data) :Data(data) {}
public:
	int Data;
};

void TestFuturePromise()
{


	auto accumulate = [](std::promise<int> &p)
	{
		int sum = 0;
		for (int i = 0; i < 5; ++i)
			sum += i;
		p.set_value(sum);
	};

	std::promise<int> p;
	std::future<int> f = p.get_future();
	std::thread t{ accumulate, std::ref(p) };
	std::cout << f.get() << '\n';
}
void TestFutureTask()
{
	//https://theboostcpplibraries.com/boost.thread-futures-and-promises
	auto accumulate = []()
	{
		int sum = 0;
		for (int i = 0; i < 5; ++i)
			sum += i;
		return sum;
	};

	std::packaged_task<int()> task(accumulate);
	std::future<int> f = task.get_future();
	std::thread t{ std::move(task) };
	std::cout << f.get() << '\n';
}

void TestAsync()
{
	auto accumulate = []()
	{
		int sum = 0;
		for (int i = 0; i < 5; ++i)
			sum += i;
		return sum;
	};

	std::future<int> f = std::async(accumulate);
	std::cout << f.get() << '\n';
}

void TestAtomic()
{
	std::atomic<int> atomicInt = 0;
	auto atomicAccess = [&]()
	{
		for (int i = 0; i < 10000; ++i)
		{
			++atomicInt;
		}
	};



	std::thread t1(atomicAccess);
	std::thread t2(atomicAccess);
	t1.join();
	t2.join();
}

void TestLockFreeAtomic()
{
	std::atomic<bool> atomicBool = false;
	std::atomic<char> atomicChar;
	std::atomic<int> atomicInt;
	std::atomic<long> atomicLong;
	std::atomic<long long> atomicLongLong;
	std::atomic<float> atomicFloat;
	std::atomic<double> atomicDouble;
	//	std::atomic<std::string> atomicString;

	std::cout << std::boolalpha;
	std::cout << "atomicBool : " << atomicBool.is_lock_free() << std::endl;
	std::cout << "atomicChar : " << atomicChar.is_lock_free() << std::endl;
	std::cout << "atomicInt : " << atomicInt.is_lock_free() << std::endl;
	std::cout << "atomicLong : " << atomicLong.is_lock_free() << std::endl;
	std::cout << "atomicLongLong : " << atomicLongLong.is_lock_free() << std::endl;
	std::cout << "atomicFloat : " << atomicFloat.is_lock_free() << std::endl;
	std::cout << "atomicDouble : " << atomicDouble.is_lock_free() << std::endl;
	//	std::cout << "atomicString" << atomicString.is_lock_free() << std::endl;

}