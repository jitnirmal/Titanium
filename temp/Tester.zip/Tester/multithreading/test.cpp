#include <iostream>
#include "ThreadedQ.h"
#include "BlockingQueue.h"

int main()
{
	//TestBlockingQueue();
	TestThreadedQ();
	return 0;
}