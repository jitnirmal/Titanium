#pragma once
#include <iostream>
#include <functional>
#include <memory>
//https://github.com/PacktPublishing/CPP-Data-Structures-and-Algorithms/blob/master/Chapter02/Doubly_Linked_List/include/DoublyLinkedList.h

using namespace std;

template<typename T>
class linked_list
{
private:
	struct node
	{
		T value;
		shared_ptr<node> next;
		shared_ptr<node> prev;

		node(const T x)
		{
			this->value = x;
			this->next = nullptr;
			this->prev = nullptr;
		}
		~node()
		{
			cout << ">> destruct " << this->value << "\n";
		}
	};

	shared_ptr<node> _firstNode;
	shared_ptr<node> _lastNode;
	unsigned int _count = { 0 };

public:
	linked_list() noexcept
		:_firstNode(nullptr),_lastNode(nullptr) 
	{
	}

	~linked_list() noexcept
	{
		auto node = _firstNode;
		while (node)
		{
			auto next = node->next;
			node->prev = node->next = nullptr;
			node = next;
		}
		// first = _end = NULL;
	}


	void insert(const T x)
	{
		if (_firstNode == NULL)
		{
			_firstNode = make_shared<node>(x);
			_lastNode = _firstNode;
		}
		else
		{
			auto node_to_add = make_shared<node>(x);
			_lastNode->next = node_to_add;
			node_to_add->prev = _lastNode;
			_lastNode = node_to_add;
		}
		++_count;
	}
/*
	void insertAt(const T x, unsigned int pos)
	{
		if (pos == 0)
		{
			auto node_to_add = make_shared<node>(x);
			node_to_add->next = _firstNode;
			_firstNode = node_to_add;
		}
		else
		{
			if (pos > _count)
			{
				// throw error
			}

			for (auto counter = 0, auto iter = _firstNode; counter < pos; ++counter, iter=iter-Next)
			{
				auto node_to_add = make_shared<node>(x);
				auto tempNode = iter->Next;
				_lastNode->next = node_to_add;
				node_to_add->prev = tempNode;
				_lastNode = node_to_add;
			}
		}
		++_count;
	}
	*/
	void remove(const T itemToDelete)
	{
		while (_firstNode->value == itemToDelete)
		{
			auto next = _firstNode->next;
			if (next)
				next->prev = nullptr;
			_firstNode = next;
			--_count;
		}


		auto x = _firstNode;
		while (x)
		{
			if (itemToDelete == x->value)
			{
				auto prev = x->prev;
				auto next = x->next;
				prev->next = next;

				if (next)
					next->prev = prev;

				if (x == _lastNode)
					_lastNode = prev;

				--_count;
			}

			x = x->next;
		}
	}

	void remove(function<bool(T)> predicate)
	{
		while (predicate(_firstNode->value))
		{
			auto next = _firstNode->next;
			if (next)
				next->prev = nullptr;
			_firstNode = next;
		}


		auto x = _firstNode;
		while (x)
		{
			if (predicate(x->value))
			{
				auto prev = x->prev;
				auto next = x->next;
				prev->next = next;

				if (next)
					next->prev = prev;

				if (x == _lastNode)
					_lastNode = prev;
			}

			x = x->next;
		}
	}

	void print() const noexcept
	{
		for (auto iter = _firstNode; iter!=nullptr ; iter = iter->next)
			std::cout << iter->value << " ";
		std::cout << "\n";
	}

	void rev_print() const noexcept
	{
		for (auto revIter = _lastNode; revIter != nullptr ; revIter = revIter->prev)
			std::cout << revIter->value << " ";
		std::cout << "\n";
	}
	
	void Size() const noexcept
	{
		return _count;
	}

};

void TestLinkedList()
{
	auto deleter = [](const auto& num) { return (num % 2 == 0); };

	std::vector<int> vi = { 1,2,3,4,2,5,3,4,6,7 };
	linked_list<int> LinkedList;
	for (auto item : vi)
	{
		LinkedList.insert(item);
	}
	
	LinkedList.rev_print();

	LinkedList.print();
	LinkedList.remove(3);
	//LinkedList.remove(deleter);
	LinkedList.print();
}