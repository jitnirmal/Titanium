#pragma once
#include <memory>
class RefCount
{
private:
	int _count{ 0 };
public:
	void Increment()
	{
		++_count;
	}
	int Decrement()
	{
		return --_count;
	}
	int GetCount() const
	{
		return _count;
	}
};

template <typename T>
class smart_ptr
{
private:
	T * m_Object{ nullptr };
	RefCount* m_RefCount{ nullptr };

public:
	smart_ptr()
	{
	}
	
	//Constructor
	smart_ptr(T* object)
		: m_Object{ object }
		, m_RefCount{ new RefCount() }
	{
		m_RefCount->Increment();
	}
	//Destructor
	virtual ~smart_ptr()
	{
			int decrementedCount = m_RefCount->Decrement();
			if (decrementedCount <= 0)
			{
				delete m_RefCount;
				delete m_Object;
				m_RefCount = nullptr;
				m_Object = nullptr;
		}
	}
	
	// Copy Constructor
	smart_ptr(const smart_ptr<T>& other)
		: m_Object{ other.m_Object }
		, m_RefCount{ other.m_RefCount }
	{
		m_RefCount->Increment();
	}

	// Move Constructor
	smart_ptr(smart_ptr<T>&& other)
		: m_Object{ other.m_Object }
		, m_RefCount{ other.m_RefCount }
	{
		m_RefCount->Increment();
	}


	// Overloaded Assignment Operator
	smart_ptr<T>& operator=(const smart_ptr<T>& other)
	{
		if (this != &other)
		{
			if (m_RefCount && m_RefCount->Decrement() == 0)
			{
				delete m_RefCount;
				delete m_Object;
			}
			m_Object = other.m_Object;
			m_RefCount = other.m_RefCount;
			m_RefCount->Increment();
		}
		return *this;
	}
	smart_ptr<T>& operator=(const smart_ptr<T>& other)
	{
			if (m_RefCount && m_RefCount->Decrement() == 0)
			{
				delete m_RefCount;
				delete m_Object;
			}
			m_Object = other.m_Object;
			m_RefCount = other.m_RefCount;
			m_RefCount->Increment();
		return *this;
	}

	SharedPointer(SharedPointer&& o) noexcept : SharedPointer() { swap(o); }

	//Dereference operator
	T& operator*()
	{
		return *m_Object;
	}
	//Member Access operator
	T* operator->()
	{
		return m_Object;
	}
};

void testSharedPointer()
{
	std::shared_ptr<int> sp(new int());
}