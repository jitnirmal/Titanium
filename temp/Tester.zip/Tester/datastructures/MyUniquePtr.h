#pragma once
#include <algorithm>
#include <iostream>


template<class T> 
class m_unique_ptr 
{


public:
	m_unique_ptr(m_unique_ptr const &) = delete;
	m_unique_ptr& operator=(m_unique_ptr const &) = delete;
	
	explicit m_unique_ptr(T * p = 0) noexcept : _ptr(p)	{}
	
	m_unique_ptr(void) noexcept : _ptr(nullptr)	{ }

	m_unique_ptr(m_unique_ptr&& rhs) noexcept{
		std::swap(_ptr, rhs._ptr);
		rhs.reset();
	}
	
	m_unique_ptr& operator=(m_unique_ptr&& rhs) noexcept {
		std::swap(_ptr, rhs._ptr);
		rhs.reset();
		return *this;
	}

	~m_unique_ptr() noexcept
	{
		destroy();
	}

	void reset(T * p = 0) noexcept 	{
		if (px != p){
			destroy();
			px = p;
		}
	}

	T& operator*() const noexcept {
		return *_ptr;
	}

	T* operator->() const noexcept{
		return _ptr;
	}

	T* get() const noexcept {
		return _ptr;
	}
private:
	inline void destroy(void) noexcept 	{
		delete _ptr;
		_ptr = nullptr;
	}
private:
	T * _ptr;
};


void TestUniquePtr()
{
	using intPtr = m_unique_ptr<int>;
	intPtr mup1(new int);
	*mup1 = 100;
	std::cout << "value1 : " << *mup1 << std::endl;
	std::cout << "value2 : " << *(mup1.get()) << std::endl;
	std::unique_ptr<int> ui = std::make_unique<int>(10);
	//intPtr mup2 = mup1;
	//intPtr mup3(mup1);

}