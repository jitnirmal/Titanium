#include <iostream>
#include <thread>
#include <chrono>
#include "sort.h"
#include "CUtils.h"
#include "LinkedList.h"
#include "MyUniquePtr.h"
#include "BinaryTree.h"
#include <iostream> 
#include <thread> 
#include <utility>

void TestThread()
{
	// 2 errors on thread lifetime
	//http://www.modernescpp.com/index.php/threads-lifetime
	//https://github.com/lefticus/cppbestpractices
		std::thread t([] {std::cout << std::this_thread::get_id(); });
		std::thread t2([] {std::cout << std::this_thread::get_id(); });

		t.join();
		
		t = std::move(t2);
		std::cout << std::boolalpha << "t2.joinable(): " << t2.joinable() << std::endl;

		t2.join();

}

int main(int argc, char *argv[])
{

	std::cout<<"testing multithreading "<<std::endl;
//Tes_C_tUtils();
//	TestUtils();
//	Tes_checkUniqueString();
//	TestReverseString();
//	TestLinkedList();
//	TestUniquePtr();
	//TestThread();
	TestBinaryTree();
}
