#include "BalancedParentheses.h"
#include "Ticket.h"
#include "Multiply.h"
#include "BInaryCount.h"
#include "NextNumber.h"
#include "Utils.h"





int main(int argc, char *argv[])
{
	//testParanthesesBalanced();
	//TestCalculateMinCost();
	//TestBinaryCount();
	//testNextNum();
	//testParanthesesBalanced();
	//TestUtils();
	TestBinaryCount();
}
