#pragma once


class Data
{
public:
	virtual void sort() const = 0;
};