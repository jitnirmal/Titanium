#include <iostream>
#include <thread>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>


void Test()
{
	auto seperator = []() {
		std::cout << "\n------------------------------------" << std::endl;
	};

	std::vector<int> vrates = { 1,2,3,4,5,6,7,8,9 };
	seperator();
	for (int i : vrates) {
		std::cout << " " << i;
	}
	seperator();

	for (auto& i : vrates) {
		i *= i;
	}

	for (const auto& i : vrates) {
		std::cout << " " << i;
	}
	seperator();

	std::map<std::string, int> mAge = { {"nirmal",37},{ "manjit",36 },{ "samar",8 },{ "seerat",4 } };
	for (const auto& record : mAge) {
		std::cout << " Name : " << record.first << " ,Age : " << record.second << std::endl;
	}
	seperator();

	std::unordered_map<std::string, int> uoAge = { { "nirmal",37 },{ "manjit",36 },{ "samar",8 } };
	uoAge["seerat"] = 4;
	for (const auto& record : uoAge) {
		std::cout << " Name : " << record.first << " ,Age : " << record.second << std::endl;
	}

	const auto searchStr = std::string{"seerat"};
	const auto& citer = uoAge.find(searchStr);
	if ( citer != uoAge.cend())
	{
		std::cout << "Age of " << searchStr << " is " << citer->second << std::endl;
	}
	

	seperator();
}

template<class ForwardIt, class Generator>
void n_generate(ForwardIt first, ForwardIt last, Generator g)
{
	while (first != last) {
		*first++ = g();
	}
}

template<class InputIt, class OutputIt, class UnaryOperation>
OutputIt n_transform(InputIt first1, InputIt last1, OutputIt d_first,	UnaryOperation unary_op)
{
	while (first1 != last1) {
		*d_first++ = unary_op(*first1++);
	}
	return d_first;
}

void vectorTest()
{
	constexpr int MAX_ITEMS{ 1000 };
	std::vector<int> vi(MAX_ITEMS,0);
	std::vector<int> vo;
	n_generate(std::begin(vi), std::end(vi), [n=0]()mutable { return ++n; });
	n_transform(std::begin(vi), std::end(vi), std::back_inserter(vo),[](int n){ return n*n; });
}

void func(int arr1[], int arr2[])
{
	auto print = [](int* arr, size_t length) {
		for (auto i = 0u; i < length; ++i)
		{
			std::cout << arr[i] << " ";
		}
	};

	size_t array_length = sizeof(arr1);

	for (auto i = 0u; i < array_length; ++i)
	{
		for (auto j = 0u; j < array_length; ++j)
		{
			if (i != j)
			{
				arr2[i] *= arr1[j];
			}
		}

	}
	print(arr2, array_length);
}

int main(int argc, char *argv[])
{
	int A[] = { 2, 1, 5, 9 };
	int B[] = { 1, 1, 1, 1 };
	func(A, B);

	std::cout<<"testing Containers "<<std::endl;
	vectorTest();
//	Test();
}
