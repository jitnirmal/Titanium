#pragma once  
#include <utility> // std::move<T>
#include <iostream>  
#include <algorithm>  
#include <vector> 
auto print = [](const auto& str) {
	std::cout << str << std::endl;
};

class Clazz {
public:
	Clazz() {
		print("constructor");
	}
	Clazz(const Clazz& other) {
		// Classical copy construction for lvalues
		print("copy constructor");
	}
	Clazz(Clazz&& other) noexcept {
		print("move constructor");
		// Move constructor for rvalues: moves content from 'other' to this
	}
	Clazz& operator=(const Clazz& other) {
		// Classical copy assignment for lvalues
		print("assignment");
		return *this;
	}
	Clazz& operator=(Clazz&& other) noexcept {
		// Move assignment for rvalues: moves content from 'other' to this
		print("move assignment");
		return *this;
	}
	// ...
};
void TestMove() {
	Clazz anObject;
	Clazz anotherObject1(anObject); // Calls copy constructor
	Clazz anotherObject2(std::move(anObject)); // Calls move constructor
	anObject = anotherObject1; // Calls copy assignment operator
	anotherObject2 = std::move(anObject); // Calls move assignment operator
}

template<typename T>
class MemoryBlock
{
public:
	explicit MemoryBlock(size_t length)
		: _length(length)
		, _data(new T[length])
	{
		std::cout << "In MemoryBlock(size_t). length = "
			<< _length << "." << std::endl;
	}

	// Destructor.  
	~MemoryBlock()
	{
		std::cout << "In ~MemoryBlock(). length = "
			<< _length << ".";

		if (_data != nullptr)
		{
			std::cout << " Deleting resource.";
			// Delete the resource.  
			delete[] _data;
		}

		std::cout << std::endl;
	}

	// Copy constructor.  
	MemoryBlock(const MemoryBlock& other)
		: _length(other._length)
		, _data(new T[other._length])
	{
		std::cout << "In MemoryBlock(const MemoryBlock&). length = "
			<< other._length << ". Copying resource." << std::endl;

		std::copy(other._data, other._data + _length, _data);
	}

	// Copy assignment operator.  
	MemoryBlock& operator=(const MemoryBlock& other)
	{
		std::cout << "In operator=(const MemoryBlock&). length = "
			<< other._length << ". Copying resource." << std::endl;

		if (this != &other)
		{
			// Free the existing resource.  
			delete[] _data;

			_length = other._length;
			_data = new int[_length];
			std::copy(other._data, other._data + _length, _data);
		}
		return *this;
	}

	// Move constructor.  
	MemoryBlock(MemoryBlock&& other)
		: _data(nullptr)
		, _length(0)
	{
		std::cout << "In MemoryBlock(MemoryBlock&&). length = "
			<< other._length << ". Moving resource." << std::endl;

		// Copy the data pointer and its length from the   
		// source object.  
		_data = other._data;
		_length = other._length;

		// Release the data pointer from the source object so that  
		// the destructor does not free the memory multiple times.  
		other._data = nullptr;
		other._length = 0;
	}

	// Move assignment operator.  
	MemoryBlock& operator=(MemoryBlock&& other)
	{
		std::cout << "In operator=(MemoryBlock&&). length = "
			<< other._length << "." << std::endl;

		if (this != &other)
		{
			// Free the existing resource.  
			delete[] _data;

			// Copy the data pointer and its length from the   
			// source object.  
			_data = other._data;
			_length = other._length;

			// Release the data pointer from the source object so that  
			// the destructor does not free the memory multiple times.  
			other._data = nullptr;
			other._length = 0;
		}
		return *this;
	}

	// Retrieves the length of the data resource.  
	size_t Length() const
	{
		return _length;
	}

private:
	size_t _length; // The length of the resource.  
	T* _data; // The resource.  
};

void testMoveMemoryBlock()
{
	// Create a vector object and add a few elements to it.  
	std::vector<MemoryBlock<int>> v;
	v.push_back(MemoryBlock<int>(25));
	v.push_back(MemoryBlock<int>(75));

	// Insert a new element into the second position of the vector.  
	v.insert(v.begin() + 1, MemoryBlock<int>(50));
}
/*
Output ....

In MemoryBlock(size_t). length = 25.
In MemoryBlock(MemoryBlock&&). length = 25. Moving resource.
In ~MemoryBlock(). length = 0.
In MemoryBlock(size_t). length = 75.
In MemoryBlock(MemoryBlock&&). length = 25. Moving resource.
In ~MemoryBlock(). length = 0.
In MemoryBlock(MemoryBlock&&). length = 75. Moving resource.
In ~MemoryBlock(). length = 0.
In MemoryBlock(size_t). length = 50.
In MemoryBlock(MemoryBlock&&). length = 50. Moving resource.
In MemoryBlock(MemoryBlock&&). length = 50. Moving resource.
In operator=(MemoryBlock&&). length = 75.
In operator=(MemoryBlock&&). length = 50.
In ~MemoryBlock(). length = 0.
In ~MemoryBlock(). length = 0.
In ~MemoryBlock(). length = 25. Deleting resource.
In ~MemoryBlock(). length = 50. Deleting resource.
In ~MemoryBlock(). length = 75. Deleting resource.

*/
